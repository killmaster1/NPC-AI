#ifndef __AML_PSDK_SAFXPRIMITIVES_H
#define __AML_PSDK_SAFXPRIMITIVES_H

#include <plugin-sdk/game_sa/base/Lists.h>
#include <plugin-sdk/game_sa/plugin.h>
#include <plugin-sdk/gta_base/Vector.h>
#include <plugin-sdk/renderware/RwMatrix.h>
#include <plugin-sdk/renderware/RwRGBA.h>

struct FxSystem_c;

DECL_CLASS(FxName32_t)
// Member values
char txt[32];
DECL_CLASS_END()
CHECKSIZE(FxName32_t, 0x20, 0x20);

DECL_CLASS(EmissionInfo_t)
// Member values
float count;
float radius;
RwV3d sizeMin;
RwV3d sizeMax;
RwV2d speed;
RwV3d dir;
RwV2d angle;
RwV2d life;
RwV3d pos;
float rot[2];
float weather[4];
DECL_CLASS_END()
CHECKSIZE(EmissionInfo_t, 0x68, 0x68);

DECL_CLASS(MovementInfo_t)
// Member values
RwV3d pos;
RwV3d vel;
float rot[4];
u8 hasFloatInfo;
u8 hasUnderwaterInfo;
DECL_CLASS_END()
CHECKSIZE(MovementInfo_t, 0x2c, 0x2c);

DECL_CLASS(RenderInfo_t)
// Member values
RwRGBA colour;
RwRGBA colour2;
i32 colId;
RwV2d size;
RwV2d sizeBias;
RwV4d spriteRect;
i32 trailId;
float trailTime;
u8 hasAnimTextures;
i8 currTexId;
u8 hasHeatHaze;
u8 isSelfLit;
RwMatrix flatMat;
u8 isFlat;
u8 hasDir;
u8 useVel;
i8 smokeType;
RwV3d dirVec;
float smokeRed;
float smokeGreen;
float smokeBlue;
float smokeAlpha;
float smokeBright;
float smokeSize;
float smokeTime;
DECL_CLASS_END()
CHECKSIZE(RenderInfo_t, 0xa4, 0xa4);

struct FxBox_c {
    FxBox_c() {
        m_fCornerA_x = m_fCornerA_y = m_fCornerA_z = 999999.0f;
        m_fCornerB_x = m_fCornerB_y = m_fCornerB_z = -999999.0f;
    }

    float m_fCornerA_x;
    float m_fCornerB_x;
    float m_fCornerA_y;
    float m_fCornerB_y;
    float m_fCornerA_z;
    float m_fCornerB_z;
};

struct FxPlane_c {
    RwV3d m_vecNormal;
    float m_fDistance;
};

struct Particle_c : ListItem_c {};

struct FxEmitterPrt_c : Particle_c {
    float m_life;
    float m_currLife;
    RwV3d m_pos;
    RwV3d m_vel;
    FxSystem_c *m_fxSysPtr;
    unsigned char m_multR;
    unsigned char m_multG;
    unsigned char m_multB;
    unsigned char m_multA;
    unsigned char m_multSize;
    unsigned char m_multRot;
    unsigned char m_randR;
    unsigned char m_randG;
    unsigned char m_randB;
    unsigned char m_brightness;
    unsigned char m_zRot;
    unsigned char m_localToSystem;
    float m_currRot;
};

DECL_CLASS(FxPrtMult_c)
// Construct/Deconstruct functions
DECL_CTORCALL_PROXY(FxPrtMult_c1, _ZN11FxPrtMult_cC2Ev);
DECL_CTORCALL_ARG_HEAD(FxPrtMult_c, _ZN11FxPrtMult_cC2Efffffff, float red, float green, float blue, float alpha,
                       float size, float arg5, float lastFactor)
DECL_CTORCALL_ARG_TAIL(red, green, blue, alpha, size, arg5, lastFactor)

FxPrtMult_c() {
    m_color.red = m_color.green = m_color.blue = m_color.alpha = 1.0f;
    m_fSize = m_fRotation = m_fLife = 1.0f;
}

RwRGBAReal m_color;
float m_fSize;
float m_fRotation;
float m_fLife;

// Member functions
DECL_THISCALL_HEAD(SetUp, _ZN11FxPrtMult_c5SetUpEfffffff, void, float red, float green, float blue, float alpha,
                   float size, float arg5, float lastFactor)
DECL_THISCALL_TAIL(SetUp, red, green, blue, alpha, size, arg5, lastFactor)
DECL_CLASS_END()

DECL_CLASS(FxSphere_c)
// Construct/Deconstruct functions
DECL_CTORCALL_PROXY(FxSphere_c, _ZN10FxSphere_cC2Ev);
FxSphere_c() { m_nNumPlanesPassed = 0; }
DECL_FASTCALL_SIMPLE(FuncProxy_opnewFxSphere_c, BYBIT(_ZN10FxSphere_cnwEji, _ZN10FxSphere_cnwEmi), FxSphere_c *,
                     size_t size, i32 useHeap);
inline static FxSphere_c *Instantiate(size_t size = sizeof(FxSphere_c), i32 useHeap = 1) {
    return FuncProxy_opnewFxSphere_c(size, useHeap);
}
DECL_DLCALL(FxSphere_c, _ZN10FxSphere_cdlEPv)

// Member functions
DECL_THISCALL_HEAD(IsCollision, _ZN10FxSphere_c11IsCollisionEPS_, u8, FxSphere_c *sphere)
DECL_THISCALL_TAIL(IsCollision, sphere)

DECL_THISCALL_HEAD(GetDistToPlane, _ZN10FxSphere_c14GetDistToPlaneEP9FxPlane_c, float, FxPlane_c *plane)
DECL_THISCALL_TAIL(GetDistToPlane, plane)

// Member values
RwV3d m_vecCenter;
float m_fRadius;
int m_nNumPlanesPassed;
DECL_CLASS_END()

DECL_CLASS(FxFrustumInfo_c)
// Member functions
DECL_THISCALL_HEAD(IsCollision, _ZN15FxFrustumInfo_c11IsCollisionEP10FxSphere_c, int, FxSphere_c *sphere)
DECL_THISCALL_TAIL(IsCollision, sphere)

// Member values
FxSphere_c m_sphere;
FxPlane_c m_planes[4];
DECL_CLASS_END()

#endif // __AML_PSDK_SAFXPRIMITIVES_H
