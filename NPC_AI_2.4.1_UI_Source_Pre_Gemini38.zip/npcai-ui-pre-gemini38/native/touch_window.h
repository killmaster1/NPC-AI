#pragma once
#include <mod/thirdparty/imgui/imgui.h>

// NoInputs is a composite flag containing NoNav bits. A bitwise test against
// NoInputs therefore rejects keyboard-navigation-free mobile windows by mistake.
inline bool NpcImGuiWindowAcceptsTouch(ImGuiWindowFlags flags) {
    return !(flags & ImGuiWindowFlags_NoMouseInputs) && !(flags & ImGuiWindowFlags_ChildWindow);
}
