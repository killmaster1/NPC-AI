#include "ui.h"
#include "thread_ownership.h"
#ifdef __ANDROID__
#include <mod/logger.h>
#endif
#include "game_bridge.h"
#include "native_keyboard.h"
#ifdef __ANDROID__
#include "android_eleven.h"
#endif
#include "bubble_layout.h"
#include "ui_layout.h"
#include "../../backend_control.h"
#include <mod/thirdparty/imgui/imgui.h>
#include <algorithm>
#include <array>
#include <cstring>
#include <string>
#include <vector>

namespace {
npcai::Chat* chat=nullptr;
char input[1201]{};
bool shift=false;
int page=0;
bool keyboardOpen=false;
bool historyOpen=false;
std::string inputMode="compact";
float userScale=1.f;
bool showDiagnosticButton=true;
std::string lastId;
uint64_t lastRevision=0;
uint64_t cachedRevision=~uint64_t{};
std::string cachedId;
std::vector<std::string> cachedMessages;
std::string cachedLatestNpc;
float bubbleGap=6;
std::shared_ptr<npcai::Diagnostics> diagnostics;
bool diagnosticOpen=false;
std::shared_ptr<npcai::VoiceManager> voice;

constexpr ImVec4 kPanel{.055f,.065f,.055f,.94f};
constexpr ImVec4 kPanelSoft{.075f,.09f,.075f,.96f};
constexpr ImVec4 kGrove{.29f,.55f,.24f,1.f};
constexpr ImVec4 kGroveBright{.48f,.78f,.35f,1.f};
constexpr ImVec4 kWarm{.94f,.78f,.38f,1.f};
constexpr ImVec4 kMuted{.68f,.72f,.66f,1.f};

void RefreshMessageCache(const npcai::Snapshot& s,const std::string& id){
    if(cachedRevision==s.revision && cachedId==id)return;
    cachedRevision=s.revision;cachedId=id;cachedMessages.clear();cachedLatestNpc.clear();
    cachedMessages.reserve(s.messages.size());
    for(const auto& message:s.messages){
        cachedMessages.push_back(std::string(message.fromPlayer?"CJ  ":"NPC  ")+message.text);
        if(!message.fromPlayer)cachedLatestNpc=message.text;
    }
}

std::string Transcript(const npcai::Snapshot& s){
    std::string value;size_t bytes=0;for(const auto& message:s.messages)bytes+=message.text.size()+10;
    value.reserve(bytes);
    for(const auto& message:s.messages)value+=(message.fromPlayer?"CJ: ":"NPC: ")+message.text+"\n\n";
    if(s.waiting)value+="NPC está pensando...\n";
    if(!s.error.empty())value+="Erro: "+s.error+"\n";
    return value;
}
void DiagnosticPanel(float scale,ImVec2 screen){
    if(!diagnosticOpen || !diagnostics)return;
    ImGui::SetNextWindowPos({screen.x*.03f,screen.y*.03f},ImGuiCond_Appearing);
    ImGui::SetNextWindowSize({screen.x*.94f,screen.y*.94f},ImGuiCond_Appearing);
    if(ImGui::Begin("NPC AI · Diagnóstico",nullptr,ImGuiWindowFlags_NoSavedSettings)){
        if(ImGui::Button("Voltar",{100*scale,36*scale}))diagnosticOpen=false;
        ImGui::SameLine();const auto d=diagnostics->Get();
        ImGui::BeginDisabled(d.testing);if(ImGui::Button("Testar Gemini",{170*scale,36*scale}))diagnostics->TestGemini();ImGui::EndDisabled();
        if(ImGui::Button("Exportar relatório"))diagnostics->Export();
        ImGui::TextWrapped("%s",d.testStatus.c_str());
        if(!d.exportStatus.empty())ImGui::TextWrapped("%s",d.exportStatus.c_str());
        if(voice){
            ImGui::Separator();ImGui::TextUnformatted("Voz e personalidade");
            auto config=voice->Options();auto v=voice->Status();bool enabled=config.ttsEnabled,spatial=config.ttsSpatial;float speed=config.ttsSpeed,volume=config.ttsVolume;
            int engine=config.ttsEngine=="elevenlabs"?1:0;const char* engines[]={"Kokoro offline","ElevenLabs HTTPS"};
            if(ImGui::Combo("Motor",&engine,engines,2)){voice->Cancel();voice->Control("engine",engine?"elevenlabs":"kokoro");}
            bool changed=ImGui::Checkbox("Ativar voz",&enabled);int selected=config.ttsVoice=="pm_santa"?1:config.ttsVoice=="pf_dora"?2:0;
            if(engine==0){bool variation=config.ttsVariation;if(ImGui::Checkbox("Variar a voz por NPC",&variation))voice->SetVariation(variation);const char* names[]={"pm_alex (43)","pm_santa (44)","pf_dora (42)"};changed=ImGui::Combo("Voz padrão / teste",&selected,names,3)||changed;}
            else if(engine==1){
                int model=config.elevenModel=="eleven_flash_v2_5"?1:0;const char* models[]={"Eleven v3 (tags controladas)","Flash v2.5 (sem tags)"};
                if(ImGui::Combo("Modelo ElevenLabs",&model,models,2)){voice->Cancel();voice->Control("model",model?"eleven_flash_v2_5":"eleven_v3");}
                ImGui::TextWrapped("Voice ID: %s | Nome: %s",v.voiceId.empty()?"aguardando primeira fala":v.voiceId.c_str(),v.voiceName.c_str());
                ImGui::TextWrapped("Credencial própria: %s | HTTP: %d",v.keyStatus.empty()?"consulte status":v.keyStatus.c_str(),v.lastHttp);
#ifdef __ANDROID__
                if(ImGui::Button("Importar chave (Keystore)"))npcai::AndroidEleven::ImportEditor();
#endif
                if(ImGui::Button("Remover chave ElevenLabs"))voice->Control("remove_key");ImGui::SameLine();if(ImGui::Button("Atualizar status"))voice->Control("status");
                if(ImGui::Button("Consultar vozes da conta"))voice->Control("refresh_voices");
                ImGui::TextWrapped("Vozes locais/mapeamentos são configurados no INI. Consulta não sintetiza áudio. Não há fallback automático.");
                ImGui::TextWrapped("Caracteres enviados: %llu | Requisições: %llu | Cache hits: %llu | Evitadas: %llu",(unsigned long long)v.sentCharacters,(unsigned long long)v.requests,(unsigned long long)v.cacheHits,(unsigned long long)v.avoided);
                ImGui::TextWrapped("Estimativa hora: %.1f / %.1f | dia UTC: %.1f / %.1f",v.hourCredits,config.elevenHour,v.dayCredits,config.elevenDay);
                ImGui::TextWrapped("%s",v.creditStatus.c_str());if(ImGui::Button("Limpar cache de áudio"))voice->Control("clear_cache");
            }
            const bool canSpeed=engine==0 || config.elevenModel=="eleven_flash_v2_5";ImGui::BeginDisabled(!canSpeed);changed=ImGui::SliderFloat("Velocidade",&speed,.7f,1.2f)||changed;ImGui::EndDisabled();
            if(engine==0)ImGui::TextWrapped("Kokoro FP32: frases preservadas; ritmo discreto. Compare Alex, Santa e Dora. Sem tags emocionais ou pitch artificial.");
            if(!canSpeed)ImGui::TextWrapped("v3: entonação pelo texto/tags; speed não é enviado.");
            changed=ImGui::SliderFloat("Volume",&volume,0.f,1.f)||changed;changed=ImGui::Checkbox("Áudio espacial estéreo",&spatial)||changed;
            if(changed)voice->Configure(enabled,npcai::KokoroVoices[selected],speed,volume,spatial);
            ImGui::TextWrapped("Emoção da última fala: %s | intensidade: %.2f | relação: %s | confiança em CJ: %.0f/100",v.emotion.c_str(),v.intensity,v.relationship.c_str(),v.trust);
            ImGui::TextWrapped("Multiplicador agressividade: %.2f | limite de palavrões: %d (INI)",config.aggressionMultiplier,config.profanityLevel);
            ImGui::TextWrapped("Ajustes do menu valem nesta sessão; use o INI para persistir.");
            const char* testLabel=engine?"Testar voz (cache ou créditos ElevenLabs)":"Testar voz";
            if(ImGui::Button(testLabel))voice->Test();ImGui::SameLine();if(ImGui::Button("Interromper voz"))voice->Cancel();
            ImGui::TextWrapped("%s: %s | Modelo: %s | Idioma: %s",v.engine.c_str(),v.state.c_str(),v.model.c_str(),v.language.c_str());
            ImGui::TextWrapped("Fonemização: %s | ONNX: %s",v.phonemizer.c_str(),v.onnx.c_str());
            ImGui::TextWrapped("Síntese: %llu ms | Áudio: %llu ms | memória mínima: %.1f MiB",(unsigned long long)v.synthMs,(unsigned long long)v.audioMs,v.approxBytes/1048576.);
            ImGui::TextWrapped("Erro TTS: %s",v.error.empty()?"nenhum":v.error.c_str());
        }
        ImGui::Separator();
        ImGui::TextWrapped("Versão: %s | INI: %s",d.version.c_str(),d.iniPath.c_str());
        ImGui::TextWrapped("UI/touch: %s",d.uiBuild.c_str());
        ImGui::TextWrapped("INI %s | Configuração %s",d.iniFound?"encontrado":"ausente (padrões)",d.configValid?"válida":"com erros recuperados");
        ImGui::TextWrapped("Transporte: %s | Gemini: %s",d.transport.c_str(),d.geminiEnabled?"ativado":"desativado");
        ImGui::TextWrapped("Modelo: %s | Credencial: %s",d.model.c_str(),d.credentialPresent?"presente":"ausente");
        ImGui::TextWrapped("HTTPS: %s | INTERNET: %s",d.httpsAvailable?"disponível":"indisponível",d.internet<0?"desconhecida":d.internet?"permitida":"negada");
        ImGui::TextWrapped("Último HTTP: %d | Erro: %s",d.lastHttp,d.lastError.empty()?"nenhum":d.lastError.c_str());
        ImGui::TextWrapped("GameBridge: %s | Seleção: %s",d.gameBridgeReady?"pronto":"indisponível",d.selection.c_str());
        ImGui::TextWrapped("Balões: %s",d.bubbles.c_str());
        for(const auto& error:d.errors)ImGui::TextWrapped("Config: %s",error.c_str());
        for(const auto& warning:d.warnings)ImGui::TextWrapped("Aviso: %s",warning.c_str());
    }ImGui::End();
}


void Append(const char* s) {
    size_t n=std::strlen(input), m=std::strlen(s);
    if(n+m<sizeof input) std::memcpy(input+n,s,m+1);
}
void Backspace() {
    size_t n=std::strlen(input);if(!n) return;
    do{--n;}while(n && (static_cast<unsigned char>(input[n])&0xC0)==0x80);
    input[n]=0;
}
void Row(const std::array<const char*,10>& keys,float height) {
    float width=(ImGui::GetContentRegionAvail().x-9*ImGui::GetStyle().ItemSpacing.x)/10;
    for(int i=0;i<10;++i){
        if(i) ImGui::SameLine();
        ImGui::PushID(i);
        if(ImGui::Button(keys[i],{width,height})) Append(keys[i]);
        ImGui::PopID();
    }
}
void Keyboard(float height) {
    const std::array<const char*,10> low1={"q","w","e","r","t","y","u","i","o","p"};
    const std::array<const char*,10> low2={"a","s","d","f","g","h","j","k","l","ç"};
    const std::array<const char*,10> low3={"z","x","c","v","b","n","m",",",".","?"};
    const std::array<const char*,10> up1={"Q","W","E","R","T","Y","U","I","O","P"};
    const std::array<const char*,10> up2={"A","S","D","F","G","H","J","K","L","Ç"};
    const std::array<const char*,10> up3={"Z","X","C","V","B","N","M","!",".","?"};
    const std::array<const char*,10> num={"1","2","3","4","5","6","7","8","9","0"};
    const std::array<const char*,10> signs1={"!","?",",",".",":",";","'","\"","(",")"};
    const std::array<const char*,10> signs2={"+","-","*","/","=","@","#","$","%","&"};
    const std::array<const char*,10> accents1={"á","à","â","ã","é","ê","í","ó","ô","õ"};
    const std::array<const char*,10> accents2={"Á","À","Â","Ã","É","Ê","Í","Ó","Ô","Õ"};
    const std::array<const char*,10> accents3={"ú","ü","ç","Ú","Ü","Ç","[","]","_","\\"};
    ImGui::PushID("keyboard");
    ImGui::PushID(1);Row(page==1?num:page==2?(shift?accents2:accents1):(shift?up1:low1),height);ImGui::PopID();
    ImGui::PushID(2);Row(page==1?signs1:page==2?accents3:(shift?up2:low2),height);ImGui::PopID();
    ImGui::PushID(3);Row(page==1?signs2:(shift?up3:low3),height);ImGui::PopID();
    float width=(ImGui::GetContentRegionAvail().x-4*ImGui::GetStyle().ItemSpacing.x)/8;
    if(ImGui::Button(shift?"abc":"ABC",{width,height})) shift=!shift;
    ImGui::SameLine();if(ImGui::Button(page==1?"Letras":"123",{width,height})) page=page==1?0:1;
    ImGui::SameLine();if(ImGui::Button(page==2?"Letras":"áéí",{width,height})) page=page==2?0:2;
    ImGui::SameLine();if(ImGui::Button("Espaço",{width*3,height})) Append(" ");
    ImGui::SameLine();if(ImGui::Button("Apagar",{width*2,height})) Backspace();
    ImGui::PopID();
}
}
namespace NpcUi {
bool SubmitMessage(const std::string& text){if(!chat || !chat->Send(text))return false;input[0]=0;npcai::GameBridge::Sent();return true;}
void Init(npcai::Chat& instance,float gap,std::shared_ptr<npcai::Diagnostics> diag,std::shared_ptr<npcai::VoiceManager> v,const npcai::Settings* settings){
    voice=std::move(v);chat=&instance;bubbleGap=gap;diagnostics=std::move(diag);diagnosticOpen=false;
    inputMode=settings?settings->uiInputMode:"compact";historyOpen=settings && settings->uiHistoryExpanded;
    showDiagnosticButton=!settings || settings->uiDiagnosticButton;userScale=settings?settings->uiScale:1.f;keyboardOpen=false;
}
void Draw() {
    const bool ownerStable=npcai::OwnershipAudit().Record(false);
#ifdef __ANDROID__
    if(!ownerStable)logger->Error("Thread ownership mismatch: %s; device investigation required",npcai::OwnershipAudit().Details().c_str());
#else
    (void)ownerStable;
#endif
    if(!chat)return;
    const auto s=chat->Get();
    const std::string current=s.target?s.target->id:"";
    static std::string editorTarget;
    if(current!=editorTarget || !npcai::GameBridge::IsOpen()){npcai::NativeKeyboard::Invalidate();editorTarget=current;}
    npcai::NativeKeyboard::Heartbeat();
    std::string edited;
    if(npcai::NativeKeyboard::Take(edited)){
        if(edited.empty())npcai::GameBridge::Open(false);
        else if(!SubmitMessage(edited) && edited.size()<sizeof input){std::memcpy(input,edited.data(),edited.size());input[edited.size()]=0;}
    }
    RefreshMessageCache(s,current);
    auto& io=ImGui::GetIO();const auto screen=io.DisplaySize;
    if(screen.x<240 || screen.y<180){NpcImGuiCaptureAll(npcai::NativeKeyboard::Active());return;}
    const float automatic=std::clamp(std::min(screen.y/720.f,screen.x/1280.f),.72f,1.5f);
    const float scale=automatic*userScale;
    ImGui::GetStyle().FontSizeBase=std::clamp(21.f*scale,15.f,32.f);

    bool open=npcai::GameBridge::IsOpen();
    float bubbleX=0,bubbleY=0;const bool projected=s.target && npcai::GameBridge::Bubble(bubbleX,bubbleY,screen.x,screen.y);
    if(diagnostics)diagnostics->Live(npcai::GameBridge::Status(),s.target.has_value(),projected);
    if(diagnosticOpen){
        keyboardOpen=false;npcai::NativeKeyboard::Invalidate();
        DiagnosticPanel(scale,screen);NpcImGuiCaptureAll(true);return;
    }
    if(open && npcai::NativeKeyboard::Active()){NpcImGuiCaptureAll(true);return;}
    NpcImGuiCaptureAll(false); // the backend captures only the actual compact windows

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,10.f*scale);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding,7.f*scale);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{10.f*scale,8.f*scale});
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,{8.f*scale,6.f*scale});
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,{5.f*scale,5.f*scale});
    ImGui::PushStyleColor(ImGuiCol_WindowBg,kPanel);
    ImGui::PushStyleColor(ImGuiCol_ChildBg,kPanelSoft);
    ImGui::PushStyleColor(ImGuiCol_Button,{.12f,.16f,.11f,.98f});
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,{.24f,.39f,.19f,1.f});
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,kGrove);
    ImGui::PushStyleColor(ImGuiCol_Border,{.34f,.47f,.28f,.75f});

    // Technical controls stay out of the gameplay conversation.
    if(showDiagnosticButton && diagnostics && !open){
        ImGui::SetNextWindowPos({screen.x*.5f-58.f*scale,5.f*scale});
        ImGui::SetNextWindowSize({116.f*scale,34.f*scale});
        if(ImGui::Begin("##NPCAIDiagnosticLauncher",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoNav)){
            if(ImGui::Button("NPC AI",{-1,-1})){diagnosticOpen=true;npcai::NativeKeyboard::Invalidate();}
        }ImGui::End();
    }

    if(!open){
        keyboardOpen=false;
        if(s.target && projected){
            std::string caption=s.waiting?"Pensando...":cachedLatestNpc.empty()?"Conversar":cachedLatestNpc;
            if(caption.size()>160){size_t n=160;while(n && (static_cast<unsigned char>(caption[n])&0xC0)==0x80)--n;caption=caption.substr(0,n)+"...";}
            static std::string spokenBy,spokenText;static uint64_t spokenSerial=0;static double spokenUntil=0;
            if(current!=spokenBy || caption!=spokenText || spokenSerial!=s.replySerial){spokenBy=current;spokenText=caption;spokenSerial=s.replySerial;spokenUntil=ImGui::GetTime()+s.bubbleDurationMs/1000.;}
            if(!s.waiting && !cachedLatestNpc.empty() && ImGui::GetTime()>spokenUntil)caption="Conversar";
            const float width=std::min(330.f*scale,screen.x*.68f);
            const float textHeight=ImGui::CalcTextSize(caption.c_str(),nullptr,false,width-24.f*scale).y;
            const float height=std::clamp(textHeight+25.f*scale,46.f*scale,118.f*scale);
            auto origin=npcai::BubbleOrigin({bubbleX,bubbleY},width,height,screen.x,screen.y,bubbleGap,7.f*scale);
            if(origin){
                ImGui::SetNextWindowPos({origin->x,origin->y});ImGui::SetNextWindowSize({width,height});
                if(ImGui::Begin("##NPCBubble",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoNav)){
                    auto* draw=ImGui::GetWindowDrawList();const auto pos=ImGui::GetWindowPos();
                    draw->AddRectFilled({pos.x+3*scale,pos.y+4*scale},{pos.x+width+3*scale,pos.y+height+4*scale},IM_COL32(0,0,0,75),10*scale);
                    draw->AddRectFilled({pos.x,pos.y},{pos.x+4*scale,pos.y+height},ImGui::ColorConvertFloat4ToU32(kGroveBright),10*scale);
                    ImGui::SetCursorPosX(ImGui::GetCursorPosX()+5*scale);ImGui::PushTextWrapPos(width-12*scale);ImGui::TextUnformatted(caption.c_str());ImGui::PopTextWrapPos();
                    ImGui::SetCursorScreenPos(pos);const bool clicked=ImGui::InvisibleButton("##bubbleTouch",{width,height});
                    static std::string pressedTarget;if(ImGui::IsItemActivated())pressedTarget=current;
                    if(clicked && pressedTarget==current)npcai::GameBridge::Open(true);
                    draw->AddTriangleFilled({pos.x+width*.5f-7*scale,pos.y+height-1},{pos.x+width*.5f+7*scale,pos.y+height-1},{pos.x+width*.5f,pos.y+height+7*scale},IM_COL32(14,17,14,245));
                }ImGui::End();
            }
            ImGui::SetNextWindowPos({screen.x-178.f*scale,screen.y-50.f*scale});ImGui::SetNextWindowSize({168.f*scale,40.f*scale});
            if(ImGui::Begin("##NPCAILauncher",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoNav)){
                if(ImGui::Button("Conversar",{-1,-1}))npcai::GameBridge::Open(true);
            }ImGui::End();
        }
        ImGui::PopStyleColor(6);ImGui::PopStyleVar(5);return;
    }

    const auto layout=npcai::CompactConversationLayout(screen.x,screen.y,userScale,keyboardOpen,historyOpen);
    ImGui::SetNextWindowPos({layout.x,layout.y});ImGui::SetNextWindowSize({layout.width,layout.height});
    if(ImGui::Begin("##NPCConversation",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoNav)){
        const std::string name=s.target?s.target->name:"NPC indisponível";
        ImGui::PushStyleColor(ImGuiCol_Text,kWarm);ImGui::TextUnformatted(name.c_str());ImGui::PopStyleColor();
        if(s.target){ImGui::SameLine();ImGui::TextDisabled("  %.1f m",s.target->distance);}
        const float closeWidth=36.f*layout.scale;
        ImGui::SameLine();ImGui::SetCursorPosX(layout.width-closeWidth-10.f*layout.scale);
        if(ImGui::Button("—",{closeWidth,28.f*layout.scale})){keyboardOpen=false;npcai::GameBridge::Open(false);}
        ImGui::Separator();

        if(historyOpen && layout.history>0){
            const bool changed=lastId!=current || lastRevision!=s.revision;
            if(ImGui::BeginChild("##NPCCompactHistory",{0,layout.history},ImGuiChildFlags_Borders)){
                const bool atBottom=ImGui::GetScrollY()>=ImGui::GetScrollMaxY()-20.f*layout.scale;
                for(size_t i=0;i<cachedMessages.size();++i){
                    const bool player=s.messages[i].fromPlayer;ImGui::PushStyleColor(ImGuiCol_Text,player?kGroveBright:ImVec4(.92f,.92f,.84f,1));
                    ImGui::TextWrapped("%s",cachedMessages[i].c_str());ImGui::PopStyleColor();ImGui::Spacing();
                }
                if(s.waiting)ImGui::TextColored(kMuted,"NPC está pensando...");
                if(changed && (atBottom || lastId!=current))ImGui::SetScrollHereY(1.f);
            }ImGui::EndChild();lastId=current;lastRevision=s.revision;
        }else if(ImGui::BeginChild("##NPCCurrentSpeech",{0,58.f*layout.scale},ImGuiChildFlags_None,ImGuiWindowFlags_NoScrollbar)){
            if(s.waiting)ImGui::TextColored(kMuted,"NPC está pensando...");
            else if(!cachedLatestNpc.empty()){ImGui::PushStyleColor(ImGuiCol_Text,{.94f,.94f,.86f,1});ImGui::PushTextWrapPos();ImGui::TextUnformatted(cachedLatestNpc.c_str());ImGui::PopTextWrapPos();ImGui::PopStyleColor();}
            else ImGui::TextColored(kMuted,"Diga alguma coisa para começar.");
            if(!s.error.empty())ImGui::TextColored({.95f,.55f,.38f,1},"Serviço indisponível");
            ImGui::EndChild();
        }else ImGui::EndChild();
        if(historyOpen && !s.error.empty())ImGui::TextColored({.95f,.55f,.38f,1},"Serviço indisponível");

        const float sendWidth=86.f*layout.scale;const char* draft=input[0]?input:"Toque para escrever...";
        const ImVec2 composerSize{ImGui::GetContentRegionAvail().x-sendWidth-6.f*layout.scale,38.f*layout.scale};
        const ImVec2 composerPos=ImGui::GetCursorScreenPos();
        ImGui::PushID("composer");const bool composerPressed=ImGui::Button("##field",composerSize);ImGui::PopID();
        auto* composerDraw=ImGui::GetWindowDrawList();
        composerDraw->PushClipRect({composerPos.x+7.f*layout.scale,composerPos.y},{composerPos.x+composerSize.x-7.f*layout.scale,composerPos.y+composerSize.y},true);
        composerDraw->AddText({composerPos.x+8.f*layout.scale,composerPos.y+9.f*layout.scale},input[0]?IM_COL32(235,240,225,255):IM_COL32(160,170,158,255),draft);
        composerDraw->PopClipRect();
        if(composerPressed){
            historyOpen=false;
            if(inputMode=="native")npcai::NativeKeyboard::Show(input,Transcript(s));else keyboardOpen=!keyboardOpen;
        }
        ImGui::SameLine();ImGui::BeginDisabled(s.waiting || !s.target || !input[0]);
        if(ImGui::Button("Enviar",{sendWidth,38.f*layout.scale})){SubmitMessage(input);keyboardOpen=false;}
        ImGui::EndDisabled();

        const float actionWidth=(ImGui::GetContentRegionAvail().x-3*ImGui::GetStyle().ItemSpacing.x)/4.f;
        if(ImGui::Button(historyOpen?"Fala atual":"Histórico",{actionWidth,31.f*layout.scale})){historyOpen=!historyOpen;if(historyOpen)keyboardOpen=false;}
        ImGui::SameLine();
        const char* inputChoice=inputMode=="native"?"Teclado":keyboardOpen?"Recolher":"Android";
        if(ImGui::Button(inputChoice,{actionWidth,31.f*layout.scale})){
            if(inputMode=="native"){historyOpen=false;npcai::NativeKeyboard::Show(input,Transcript(s));}
            else if(keyboardOpen)keyboardOpen=false;
            else npcai::NativeKeyboard::Show(input,Transcript(s));
        }
        ImGui::SameLine();if(ImGui::Button("Trocar",{actionWidth,31.f*layout.scale})){keyboardOpen=false;npcai::GameBridge::Switch();input[0]=0;}
        ImGui::SameLine();if(ImGui::Button("Limpar",{actionWidth,31.f*layout.scale})){keyboardOpen=false;npcai::NativeKeyboard::Invalidate();chat->Clear();input[0]=0;}
        if(keyboardOpen){ImGui::Separator();Keyboard(layout.key);}
    }ImGui::End();
    ImGui::PopStyleColor(6);ImGui::PopStyleVar(5);
}
void Shutdown(){npcai::NativeKeyboard::Invalidate();if(chat) npcai::GameBridge::Open(false);chat=nullptr;diagnostics.reset();voice.reset();diagnosticOpen=false;keyboardOpen=false;historyOpen=false;input[0]=0;cachedMessages.clear();cachedLatestNpc.clear();cachedId.clear();cachedRevision=~uint64_t{};NpcImGuiCaptureAll(false);}
}
