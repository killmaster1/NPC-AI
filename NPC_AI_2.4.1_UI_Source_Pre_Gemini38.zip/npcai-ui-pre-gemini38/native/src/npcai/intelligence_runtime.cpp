#include "intelligence_runtime.h"
#include "autosave_gate.h"
#include <algorithm>
#include <chrono>
#include <sstream>
#include <cmath>
namespace npcai {
uint64_t RealMilliseconds(){return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());}
static std::string Bounded(std::string s,size_t n){if(s.size()>n){s.resize(n);while(!s.empty() && !ValidUtf8(s))s.pop_back();}return s;}
IntelligenceRuntime::IntelligenceRuntime(Settings s,std::string dir,GeminiClient::HttpsTransport transport,Log log,NpcMemoryManager::IoHook hook):settings_(s),client_(s,std::move(transport)),memory_(std::move(dir),static_cast<size_t>(s.memoryMaxMb)*1024*1024),log_(std::move(log)){memory_.SetIoHook(std::move(hook));worker_=std::thread(&IntelligenceRuntime::Run,this);std::unique_lock<std::mutex> lock(stateMutex_);readyCv_.wait(lock,[&]{return ready_;});}
IntelligenceRuntime::~IntelligenceRuntime(){Shutdown();}
void IntelligenceRuntime::Interest(const std::string& id){std::lock_guard<std::mutex> lock(queueMutex_);interests_.erase(std::remove(interests_.begin(),interests_.end(),id),interests_.end());interests_.push_front(id);while(interests_.size()>4)interests_.pop_back();}
std::vector<std::string> IntelligenceRuntime::Interests(){std::lock_guard<std::mutex> lock(queueMutex_);return {interests_.begin(),interests_.end()};}
IntelligenceRuntime::Mind& IntelligenceRuntime::MindFor(const std::string& id,const Personality& traits){auto it=minds_.find(id);if(it!=minds_.end())return it->second;if(minds_.size()>=128)minds_.erase(minds_.begin());auto result=minds_.emplace(id,Mind(traits));return result.first->second;}
JsonValue IntelligenceRuntime::Context(const Request& r){
    auto& mind=MindFor(r.npcId,r.context.personality);const auto& e=mind.emotion.state;const auto& p=r.context.personality;
    JsonValue out={{"npc",{{"personality_source",r.context.personalityVariation?"generated_once_per_session_identity":"default_without_individual_variation"},{"personality",{{"courage",p.courage},{"aggression",p.aggression},{"kindness",p.kindness},{"patience",p.patience}}},{"emotional_state_local",{{"perplexity",std::round(e.perplexity)},{"fear",std::round(e.fear)},{"curiosity",std::round(e.curiosity)},{"trust",std::round(e.trust)},{"skepticism",std::round(e.skepticism)}}}}},
        {"world",{{"area",r.context.area},{"region_level",r.context.regionLevel},{"available",lastFrame_.at!=0},{"period",!lastFrame_.at?"unknown":lastFrame_.minuteOfDay>=1200 || lastFrame_.minuteOfDay<360?"night":"day"},{"age_ms",lastFrame_.at?RealMilliseconds()-lastFrame_.at:0},{"source","periodic_engine_snapshot_inference"}}},{"monitorable_expectations",JsonValue::array()},{"recent_events",JsonValue::array()},{"active_expectations",JsonValue::array()},{"memory",JsonValue::array()}};
    const auto& caps=r.context.capabilities;out["action_capabilities"]={{"captured_on_game_thread",caps.captured},{"interaction_state",caps.state},{"interaction_label",r.context.interactionState},{"allowed_precheck",caps.actions},{"refusal_code",caps.refusal},{"money_max",caps.moneyMax},{"money_session_remaining",caps.sessionRemaining},{"revalidation_required",true},{"availability_is_not_execution",true}};
    out["npc"]["social"]={{"stage",mind.relation.Stage()},{"trust",std::round(mind.relation.trust)},{"irritation",std::round(mind.relation.irritation)},{"emotion",mind.relation.emotion},{"intensity",mind.relation.intensity}};
    out["npc"]["personal_style"]={{"sociability",p.sociability},{"humor",p.humor},{"empathy",p.empathy},{"slang",p.slang},{"profanity_tendency",p.profanity}};
    if(r.context.area==0 && lastFrame_.weatherAvailable)out["world"]["rain_intensity"]=lastFrame_.rain;
    if(settings_.worldExpectations && settings_.worldPerception && lastFrame_.at){if(lastFrame_.minuteOfDay>=360 && lastFrame_.minuteOfDay<1200)out["monitorable_expectations"].push_back("night");out["monitorable_expectations"].push_back("time_reversed");out["monitorable_expectations"].push_back("ped_appeared");if(lastFrame_.weatherAvailable && lastFrame_.rain<=.15f)out["monitorable_expectations"].push_back("rain_started");if(lastFrame_.vehiclesAvailable)out["monitorable_expectations"].push_back("vehicle_appeared");if(lastFrame_.weapon>0)out["monitorable_expectations"].push_back("weapon_holstered");out["monitorable_expectations"].push_back("player_left");}
    for(const auto& observer:lastFrame_.observers)if(observer.id==r.npcId){out["world"]["player_visibility_checked"]=observer.losAvailable;out["world"]["player_visible_verified"]=observer.playerVisible;out["world"]["player_nearby_detector"]=WorldDistance(lastFrame_.player,observer.position)<=15;if(observer.playerVisible){if(lastFrame_.weapon>=0)out["world"]["equipped_weapon_type"]=lastFrame_.weapon;out["world"]["player_distance_m_approx"]=std::round(WorldDistance(lastFrame_.player,observer.position));out["world"]["moving_observed"]=lastFrame_.speed>.01f;out["world"]["aiming_flag"]=lastFrame_.aiming;out["world"]["player_in_vehicle"]=lastFrame_.inVehicle;}}
    size_t start=mind.recent.size()>3?mind.recent.size()-3:0;for(size_t i=start;i<mind.recent.size();++i)out["recent_events"].push_back(mind.recent[i]);
    for(const auto& x:mind.expectations.Active())out["active_expectations"].push_back({{"event",WorldName(x.spec.event)},{"remaining_ms",x.deadline>RealMilliseconds()?x.deadline-RealMilliseconds():0},{"count",x.spec.count}});
    if(settings_.memoryEnabled && settings_.memorySend){for(auto note:memory_.Notes({r.npcId,false},settings_.memoryGlobal))out["memory"].push_back(Bounded(note,500));}
    out["request_kind"]=r.spontaneous?"spontaneous_comment_no_player_utterance":"player_conversation";
    if(r.feedback)out["action_result"]={{"action",r.feedback->action},{"status",r.feedback->status},{"amount",r.feedback->amount}};
    const size_t budget=static_cast<size_t>(settings_.contextTokens)*3;
    for(const auto* key:{"memory","recent_events","active_expectations"})while(out.dump().size()>budget && !out[key].empty())out[key].erase(out[key].begin());
    if(out.dump().size()>budget)out["npc"].erase("personality_source");
    if(out.dump().size()>budget)out["npc"].erase("personality");
    if(out.dump().size()>budget){auto period=out["world"]["period"];auto available=out["world"]["available"];out["world"]={{"period",period},{"available",available}};out.erase("active_expectations");}
    if(out.dump().size()>budget)out["npc"].erase("personal_style");
    if(out.dump().size()>budget)out.erase("monitorable_expectations");
    if(out.dump().size()>budget)out["npc"].erase("emotional_state_local");
    if(out.dump().size()>budget)out["action_capabilities"]={{"captured_on_game_thread",caps.captured},{"refusal_code",caps.refusal},{"money_max",caps.moneyMax},{"revalidation_required",true}};
    return out;
}
Result IntelligenceRuntime::Chat(const Request& r,const std::atomic_bool& cancel){
    if(queueFault_)return {false,"Fila de contexto excedida; reinicie o jogo para proteger o save."};
    Interest(r.npcId);JsonValue context,history;
    {std::unique_lock<std::mutex> lock(stateMutex_);auto until=RealMilliseconds()+5000;
        while(appliedEpoch_!=CurrentEpoch() && !cancel && !queueFault_ && RealMilliseconds()<until)readyCv_.wait_for(lock,std::chrono::milliseconds(25));
        if(cancel || queueFault_ || appliedEpoch_!=CurrentEpoch())return {false,"Contexto de save em transição; tente novamente."};
        if(pendingEpochs_.size()>=32)pendingEpochs_.erase(pendingEpochs_.begin());
        pendingEpochs_[r.requestId]=appliedEpoch_;
        auto& social=MindFor(r.npcId,r.context.personality).relation;bool nearbyAim=false;
        for(const auto& observer:lastFrame_.observers)if(observer.id==r.npcId && observer.playerVisible)nearbyAim=lastFrame_.aiming;
        social.Observe(r.spontaneous?"":r.message,r.context.personality,nearbyAim,RealMilliseconds(),settings_);
        context=Context(r);auto it=histories_.find(r.npcId+"/"+r.conversationId);history=it==histories_.end()?JsonValue::array():it->second;}
    while(history.size()>6)history.erase(history.begin());
    const size_t budget=static_cast<size_t>(settings_.contextTokens)*3;
    while(!history.empty() && history.dump().size()+context.dump().size()>budget)history.erase(history.begin());
    auto response=client_.Chat(r,context,history,cancel);
    if(response.ok){auto d=response.decision.value_or(ParseDecision(response.text,r.requestId));std::vector<std::string> recent;
        for(const auto& item:history)if(!item.value("player",true))recent.push_back(item.value("text",""));
        d.dialogue=CleanLanguage(PlainSpeech(d.dialogue),settings_.profanityLevel,settings_.profanityRepetition,recent);
        if(settings_.emotionsEnabled){d.emotion=EmotionName(d.emotion);d.emotionIntensity*=settings_.emotionIntensity;}else{d.emotion="neutral";d.emotionIntensity=0;}
        if(context["npc"]["social"].value("irritation",0.f)<35 && d.action==Action::Angry){d.action=Action::None;if(d.emotion=="angry" || d.emotion=="furious")d.emotion="neutral";}
        d.relationship=context["npc"]["social"].value("trust",40.f);d.relationshipStage=context["npc"]["social"].value("stage","neutral");
        response.text=d.dialogue;response.decision=d;
    }
    {std::lock_guard<std::mutex> lock(stateMutex_);auto pending=pendingEpochs_.find(r.requestId);
        if(response.ok && pending!=pendingEpochs_.end() && (pending->second!=appliedEpoch_ || appliedEpoch_!=CurrentEpoch()))response={false,"Save/contexto mudou; resposta anterior descartada."};
        if(!response.ok)pendingEpochs_.erase(r.requestId);
    }return response;
}
void IntelligenceRuntime::Accepted(const Request& r,const Decision& d){
    std::lock_guard<std::mutex> q(queueMutex_);
    if(stopped_ || queueFault_ || events_.size()>=128 || std::count_if(events_.begin(),events_.end(),[](const auto& e){return e.kind==RuntimeEvent::Accepted;})>=32)throw std::runtime_error("Fila de decisões indisponível");
    RuntimeEvent event{RuntimeEvent::Accepted};event.epoch=queuedEpoch_;event.request=r;event.decision=d;events_.push_back(std::move(event));cv_.notify_one();
}
void IntelligenceRuntime::ApplyAccepted(const Request& r,const Decision& d){
    if(r.acceptanceCancelled && *r.acceptanceCancelled)return;
    auto epoch=pendingEpochs_.find(r.requestId);if(epoch!=pendingEpochs_.end()){const bool stale=epoch->second!=appliedEpoch_;pendingEpochs_.erase(epoch);if(stale)return;}
    auto& mind=MindFor(r.npcId,r.context.personality);mind.relation.emotion=d.emotion;mind.relation.intensity=d.emotionIntensity;mind.interestUntil=RealMilliseconds()+180000;
    if(histories_.size()>=64 && !histories_.count(r.npcId+"/"+r.conversationId))histories_.erase(histories_.begin());
    auto& history=histories_[r.npcId+"/"+r.conversationId];if(history.is_null())history=JsonValue::array();history.push_back({{"player",true},{"text",Bounded(r.message,1200)}});history.push_back({{"player",false},{"text",Bounded(d.dialogue,6000)}});while(history.size()>std::min<size_t>(24,settings_.historyLimit))history.erase(history.begin());
    if(settings_.worldExpectations && settings_.worldPerception && lastFrame_.at)mind.expectations.Register(r.requestId,d.expectations,RealMilliseconds(),settings_.maxExpectations,lastFrame_);
    if(settings_.memoryEnabled && settings_.memoryIndividual){if(settings_.personalityPersistent)memory_.Note(r.npcId,"Perfil da identidade de sessão: sociabilidade "+std::to_string(r.context.personality.sociability)+", paciência "+std::to_string(r.context.personality.patience)+"; relação "+mind.relation.Stage()+". Não restaurar como outro pedestre.");memory_.Note(r.npcId,(r.spontaneous?"Gatilho de comentário, não fala do jogador: ":"O jogador disse (alegação, não fato): ")+Bounded(r.message,260));memory_.Note(r.npcId,"O NPC respondeu/propos: "+Bounded(d.dialogue,260));memory_.Emotion({r.npcId,false},mind.emotion.state);}
}
uint64_t IntelligenceRuntime::CurrentEpoch(){std::lock_guard<std::mutex> q(queueMutex_);return queuedEpoch_;}
void IntelligenceRuntime::Confirmed(const std::string& npc,Action action,bool ok,int amount){
    std::lock_guard<std::mutex> q(queueMutex_);if(stopped_)return;
    if(events_.size()>=128){queueFault_=true;++queuedEpoch_;cv_.notify_one();return;}
    RuntimeEvent event{RuntimeEvent::ReceiptEvent};event.epoch=queuedEpoch_;event.receipt={npc,action,ok,amount,queuedEpoch_};events_.push_back(std::move(event));cv_.notify_one();
}
void IntelligenceRuntime::ApplyReceipt(const Receipt& receipt){
    const auto& npc=receipt.npc;const auto action=receipt.action;const bool ok=receipt.ok;const int amount=receipt.amount;
    auto found=minds_.find(npc);
    if(ok && found!=minds_.end()){
        auto& e=found->second.emotion.state;
        if(action==Action::HandsUp || action==Action::SurrenderMoney){e.fear=std::min(100.f,e.fear+15);e.trust=std::max(0.f,e.trust-10);}
        else if(action==Action::FollowPlayer)e.trust=std::min(100.f,e.trust+3);
        else if(action==Action::ReleaseSurrender)e.fear=std::max(0.f,e.fear-8);
        if(settings_.memoryEnabled && settings_.memoryIndividual)memory_.Emotion({npc,false},e);
    }
    if(!settings_.memoryEnabled || !settings_.memoryIndividual)return;
    std::string text=ok?"Efeito confirmado pelo controlador: ":"Proposta sem efeito confirmado: ";text+=ActionName(action);if(ok && amount>0)text+="; pickups criados $"+std::to_string(amount)+", coleta ainda não confirmada";memory_.Note(npc,text);
}
void IntelligenceRuntime::Submit(WorldFrame f){std::lock_guard<std::mutex> lock(queueMutex_);if(stopped_ || queueFault_)return;if(frame_)++dropped_;frameEpoch_=queuedEpoch_;frame_=std::move(f);cv_.notify_one();}
void IntelligenceRuntime::Boundary(){std::lock_guard<std::mutex> q(queueMutex_);if(stopped_)return;++queuedEpoch_;frame_.reset();flush_=true;if(events_.size()>=128)queueFault_=true;else{RuntimeEvent e{RuntimeEvent::BoundaryEvent};e.epoch=queuedEpoch_;events_.push_back(std::move(e));}cv_.notify_one();}
void IntelligenceRuntime::Slot(int slot,bool saved){if(slot<0 || slot>99)return;std::lock_guard<std::mutex> q(queueMutex_);if(stopped_)return;if(!saved || queuedSlot_!=slot)++queuedEpoch_;queuedSlot_=slot;if(!saved)frame_.reset();flush_=true;if(events_.size()>=128)queueFault_=true;else{RuntimeEvent e{RuntimeEvent::SlotEvent};e.epoch=queuedEpoch_;e.slot=slot;e.saved=saved;events_.push_back(std::move(e));}cv_.notify_one();}
void IntelligenceRuntime::Flush(){std::lock_guard<std::mutex> lock(queueMutex_);flush_=true;cv_.notify_one();}
void IntelligenceRuntime::Clear(){std::lock_guard<std::mutex> q(queueMutex_);if(stopped_)return;++queuedEpoch_;if(events_.size()>=128)queueFault_=true;else{RuntimeEvent e{RuntimeEvent::ClearEvent};e.epoch=queuedEpoch_;events_.push_back(std::move(e));}cv_.notify_one();}
std::optional<LocalReply> IntelligenceRuntime::TakeReply(){std::lock_guard<std::mutex> q(queueMutex_);while(!replies_.empty()){auto reply=std::move(replies_.front());replies_.pop_front();if(reply.epoch==queuedEpoch_)return reply;}return {};}
bool IntelligenceRuntime::AdmitSpontaneous(const LocalReply& reply,const std::function<bool()>& enqueue){
    std::unique_lock<std::mutex> q(queueMutex_);const auto now=RealMilliseconds();
    if(now-hourStart_>=3600000){hourStart_=now;spontaneousSpent_=0;admittedOpportunities_.clear();}
    if(stopped_ || queueFault_ || !reply.aiOpportunity || !reply.serial || reply.epoch!=queuedEpoch_ || admittedOpportunities_.count(reply.serial) || spontaneousSpent_>=settings_.spontaneousBudgetHour)return false;
    const auto window=hourStart_;admittedOpportunities_.insert(reply.serial);++spontaneousSpent_;q.unlock();
    bool accepted=false;try{accepted=enqueue();}catch(...){accepted=false;}
    q.lock();if(!accepted && window==hourStart_ && admittedOpportunities_.erase(reply.serial))--spontaneousSpent_;
    return accepted;
}
void IntelligenceRuntime::Process(const WorldFrame& frame){
    auto started=std::chrono::steady_clock::now();auto events=detector_.Update(frame);lastFrame_=frame;++metrics_.frames;metrics_.events+=events.size();
    for(const auto& e:events){
        if(settings_.memoryEnabled && settings_.memoryGlobal && settings_.worldEventMemory){
            auto& count=patterns_[e.kind];count=std::min(100000,count+1);
            if(count==3 && e.kind==WorldKind::TimeJump)memory_.Note("","Padrão desta sessão: mudanças abruptas de relógio se repetiram; autoria não confirmada.",true);
            if(count==3 && e.kind==WorldKind::WeaponHolstered)memory_.Note("","Padrão desta sessão: o equipamento do jogador mudou repetidamente para desarmado; intenção não confirmada.",true);
        }
        if(settings_.memoryEnabled && settings_.memoryGlobal && settings_.worldEventMemory && (e.kind==WorldKind::TimeJump || e.kind==WorldKind::RainStarted || e.kind==WorldKind::PlayerDiscontinuity))memory_.Note("",EventSummary({e,e.confidence,"engine_detector_not_npc_knowledge"}),true);
        for(const auto& observer:frame.observers){
            auto perceived=NpcPerception::Assess(e,observer);if(!perceived)continue;
            auto& mind=MindFor(observer.id,observer.personality);auto matches=mind.expectations.Observe(*perceived);metrics_.matched+=matches.size();bool matched=!matches.empty();
            if(settings_.perplexityEnabled)mind.emotion.Observe(*perceived,matched,settings_.perplexityGain);
            const auto summary=EventSummary(*perceived,matched);if(mind.recent.empty() || mind.recent.back()!=summary)mind.recent.push_back(summary);while(mind.recent.size()>8)mind.recent.pop_front();
            if(settings_.memoryEnabled && settings_.worldEventMemory){if(settings_.memoryIndividual){memory_.Note(observer.id,summary);memory_.Emotion({observer.id,false},mind.emotion.state);}if(matched && settings_.memoryGlobal)memory_.Note("",summary,true);}
            const float threshold=settings_.reactionMode=="immersive"?.5f:.75f;
            const bool important=matched || (e.intensity>threshold && perceived->confidence>.6f);
            if(important && frame.at>=mind.lastReaction+static_cast<uint64_t>(settings_.spontaneousCooldownS)*1000){
                mind.lastReaction=frame.at;LocalReply reply;reply.npc=observer.id;reply.dialogue=LocalReaction(mind.emotion.state,metrics_.events);reply.action=mind.emotion.state.fear>85 && mind.emotion.state.courage<35?Action::Flee:Action::TalkGesture;
                reply.aiOpportunity=settings_.spontaneousAI && settings_.reactionMode!="economy";
                reply.serial=++reactionSerial_;reply.epoch=appliedEpoch_;
                {std::lock_guard<std::mutex> q(queueMutex_);if(replies_.size()<8)replies_.push_back(std::move(reply));}++metrics_.reactions;
            }
        }
    }
    for(auto& pair:minds_){pair.second.relation.Recover(frame.at,settings_.relationshipRecovery);pair.second.expectations.Expire(frame.at);if(settings_.perplexityDecay && pair.second.emotion.Decay(frame.at) && settings_.memoryEnabled && settings_.memoryIndividual)memory_.Emotion({pair.first,false},pair.second.emotion.state);}
    metrics_.perceptionUs+=frame.observerCostUs+std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now()-started).count();
}
void IntelligenceRuntime::Persist(std::unique_lock<std::mutex>& lock){
    if(queueFault_)return; // A lost profile/control event must never redirect a write.
    const auto revision=memory_.Revision();auto snapshot=memory_;
    lock.unlock();const bool ok=snapshot.Save();lock.lock();
    if(ok)memory_.Acknowledge(snapshot,revision);else ++metrics_.memoryErrors;
}
void IntelligenceRuntime::Run(){
    {std::unique_lock<std::mutex> s(stateMutex_);
        try{auto profile=settings_.memoryProfile=="auto"?"unsaved-"+SessionId():settings_.memoryProfile;auto loaded=memory_;s.unlock();if(settings_.memoryEnabled && settings_.memoryPersistent)loaded.Load(profile);else loaded.Initialize(profile);if(settings_.memoryClear && settings_.memoryPersistent)loaded.Clear();s.lock();memory_=std::move(loaded);}catch(...){if(!s.owns_lock())s.lock();++metrics_.memoryErrors;}
        ready_=true;readyCv_.notify_all();lastSave_=RealMilliseconds();lastLog_=lastSave_;
    }
    AutosaveGate saveGate(static_cast<uint64_t>(settings_.memoryAutosaveSeconds)*1000);saveGate.Reset(lastSave_);
    bool faultLogged=false;
    for(;;){
        std::optional<WorldFrame> frame;std::deque<RuntimeEvent> events;uint64_t frameEpoch=0;bool flush=false,stop=false;
        {std::unique_lock<std::mutex> q(queueMutex_);cv_.wait_for(q,std::chrono::milliseconds(250),[&]{return stopped_ || frame_.has_value() || flush_ || !events_.empty();});stop=stopped_;frame=std::move(frame_);frame_.reset();frameEpoch=frameEpoch_;events.swap(events_);flush=flush_;flush_=false;}
        std::string logLine;
        {std::unique_lock<std::mutex> s(stateMutex_);
          try{
            for(const auto& event:events){
                if(queueFault_)break;
                if(event.kind==RuntimeEvent::Accepted){if(event.epoch==appliedEpoch_)ApplyAccepted(event.request,event.decision);continue;}
                if(event.kind==RuntimeEvent::ReceiptEvent){if(event.epoch==appliedEpoch_)ApplyReceipt(event.receipt);continue;}
                if(event.kind==RuntimeEvent::SlotEvent && settings_.memoryProfile=="auto"){
                    auto old=memory_.Snapshot();if(!event.saved){minds_.clear();histories_.clear();lastFrame_=WorldFrame{};}
                    if(settings_.memoryPersistent && settings_.memoryEnabled)Persist(s);
                    auto loaded=memory_;s.unlock();
                    if(settings_.memoryEnabled && settings_.memoryPersistent)loaded.Load("slot-"+std::to_string(event.slot));else loaded.Initialize("slot-"+std::to_string(event.slot));
                    if(settings_.memoryClear && settings_.memoryPersistent)loaded.Clear();
                    s.lock();memory_=std::move(loaded);if(event.saved)memory_.ForkFrom(old);detector_.Reset();
                }
                if(event.kind==RuntimeEvent::BoundaryEvent){detector_.Reset();patterns_.clear();minds_.clear();histories_.clear();lastFrame_=WorldFrame{};}
                if(event.kind==RuntimeEvent::ClearEvent){minds_.clear();histories_.clear();auto cleared=memory_;s.unlock();bool ok=true;if(settings_.memoryPersistent)ok=cleared.Clear();else cleared.Initialize(cleared.Profile());s.lock();memory_=std::move(cleared);if(!ok)++metrics_.memoryErrors;}
                appliedEpoch_=event.epoch;readyCv_.notify_all();
            }
            if(frame && settings_.worldPerception && frameEpoch==appliedEpoch_ && frameEpoch==CurrentEpoch() && !queueFault_)Process(*frame);
            uint64_t now=RealMilliseconds();
            if(settings_.memoryEnabled && settings_.memoryPersistent && saveGate.Due(now,memory_.Dirty(),flush || stop)){Persist(s);lastSave_=now;}
            metrics_.autosaves=memory_.Saves();metrics_.memoryBytes=memory_.Bytes();metrics_.memoryErrors=std::max<uint64_t>(metrics_.memoryErrors,memory_.Corruptions());
            if(queueFault_ && !faultLogged){faultLogged=true;++metrics_.memoryErrors;logLine="Context queue overflow: memory writes and AI admission stopped; restart required";}
            else if(log_ && now-lastLog_>=60000){lastLog_=now;std::ostringstream line;line<<"Intelligence metrics frames="<<metrics_.frames<<" events="<<metrics_.events<<" expectations="<<metrics_.matched<<" autosaves="<<metrics_.autosaves<<" memory_bytes="<<metrics_.memoryBytes<<" perception_us="<<metrics_.perceptionUs<<" requests="<<client_.metrics.requests<<" retries="<<client_.metrics.retries<<" tokens="<<client_.metrics.tokens<<" latency_ms="<<client_.metrics.latencyMs<<" errors="<<client_.metrics.errors;logLine=line.str();}
          }catch(...){if(!s.owns_lock())s.lock();++metrics_.memoryErrors;queueFault_=true;readyCv_.notify_all();logLine="Intelligence worker: control event failed; writes stopped to protect profile";}
        }
        if(!logLine.empty() && log_)try{log_(logLine);}catch(...){}
        if(stop)return;
    }
}
IntelligenceMetrics IntelligenceRuntime::Metrics(){std::lock_guard<std::mutex> s(stateMutex_);auto out=metrics_;out.droppedFrames=dropped_;return out;}
JsonValue IntelligenceRuntime::DebugMemory(){std::lock_guard<std::mutex> s(stateMutex_);return memory_.Snapshot();}
void IntelligenceRuntime::Shutdown(){{std::lock_guard<std::mutex> q(queueMutex_);if(stopped_)return;stopped_=true;}cv_.notify_all();if(worker_.joinable())worker_.join();}
}
