#pragma once
#include <vector>
#include <algorithm>
#include <cstddef>
namespace npcai {
// Fresh observations only: unallocated observers get no cached visual claim.
inline std::vector<size_t> ObserverSchedule(size_t count,size_t capacity,size_t round,bool pinFirst){
 std::vector<size_t> result;if(!count || !capacity)return result;
 size_t offset=pinFirst?1:0;if(pinFirst)result.push_back(0);
 for(size_t i=0;i<std::min(count-offset,capacity-offset);++i)result.push_back(offset+(round+i)%(count-offset));
 return result;
}
inline std::vector<int> VisibilityAllocation(size_t count,int budget,size_t round){
 std::vector<int> result(count,0);if(!count)return result;
 for(int i=0;i<std::max(0,budget);++i)++result[(round+static_cast<size_t>(i))%count];
 return result;
}
}
