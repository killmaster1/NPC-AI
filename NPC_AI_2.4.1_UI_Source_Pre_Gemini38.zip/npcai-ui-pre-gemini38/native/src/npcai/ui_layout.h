#pragma once
#include <algorithm>
#include <cmath>

namespace npcai {
struct ConversationLayout {
    float scale=1,margin=0,x=0,y=0,width=0,height=0,header=0,composer=0,history=0,key=0;
    bool portrait=false;
};

// Pure layout calculation: deterministic, allocation-free and independent of ImGui.
inline ConversationLayout CompactConversationLayout(float screenWidth,float screenHeight,float userScale,
                                                     bool keyboard,bool history) {
    ConversationLayout out;
    if(!std::isfinite(screenWidth) || !std::isfinite(screenHeight) || screenWidth<=0 || screenHeight<=0)return out;
    out.portrait=screenHeight>screenWidth;
    const float automatic=std::clamp(std::min(screenWidth/1280.f,screenHeight/720.f),.72f,1.5f);
    out.scale=automatic*std::clamp(userScale,.75f,1.5f);
    out.margin=std::max(6.f,10.f*out.scale);
    const float widthLimit=(out.portrait?screenWidth*.96f:screenWidth*.72f);
    out.width=std::min(widthLimit,820.f*out.scale);
    out.width=std::max(std::min(screenWidth-2*out.margin,out.width),std::min(screenWidth-2*out.margin,300.f));
    out.header=38.f*out.scale;
    out.composer=84.f*out.scale; // composer plus the compact action row
    out.key=std::clamp(42.f*out.scale,32.f,58.f);
    const float speech=58.f*out.scale;
    out.history=history?std::min(screenHeight*.34f,230.f*out.scale):0.f;
    const float keyboardHeight=keyboard?out.key*4+12.f*out.scale:0.f;
    out.height=out.margin*2+out.header+speech+out.composer+out.history+keyboardHeight;
    const float maximum=screenHeight-2*out.margin;
    if(out.height>maximum){
        float excess=out.height-maximum;
        const float shrink=std::min(out.history,excess);out.history-=shrink;out.height-=shrink;excess-=shrink;
        if(excess>0 && keyboard)out.key=std::max(28.f,out.key-excess/4.f);
        out.height=std::min(maximum,out.margin*2+out.header+speech+out.composer+out.history+(keyboard?out.key*4+12.f*out.scale:0.f));
    }
    out.x=(screenWidth-out.width)*.5f;
    out.y=screenHeight-out.height-out.margin;
    return out;
}
}
