#pragma once
#include <thread>
#include <mutex>
#include <sstream>
namespace npcai {
// Instrumentation only: no assertion that render and simulation share a thread.
class ThreadOwnership {
 std::mutex mutex_;std::thread::id game_,render_;bool warned_=false;
public:
 std::string Details(){std::lock_guard<std::mutex> lock(mutex_);std::ostringstream out;out<<"game="<<game_<<" render="<<render_<<" current="<<std::this_thread::get_id();return out.str();}
 bool Record(bool game){std::lock_guard<std::mutex> lock(mutex_);auto& owner=game?game_:render_;auto current=std::this_thread::get_id();bool mismatch=owner!=std::thread::id{} && owner!=current;if(owner==std::thread::id{})owner=current;mismatch=mismatch || (game_!=std::thread::id{} && render_!=std::thread::id{} && game_!=render_);if(mismatch && !warned_){warned_=true;return false;}return true;}
};
inline ThreadOwnership& OwnershipAudit(){static ThreadOwnership audit;return audit;}
}
