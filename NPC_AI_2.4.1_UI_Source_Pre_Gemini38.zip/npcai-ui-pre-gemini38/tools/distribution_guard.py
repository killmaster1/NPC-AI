"""Fail closed for credentials in selected distribution configs, without changing private files."""
from pathlib import Path
import json,re
SECRET_KEYS={'token','api_key','apikey','gemini_api_key','elevenlabs_api_key','openai_api_key','npc_ai_token','password','secret','authorization'}
def check_files(paths):
    for path in paths:
        p=Path(path)
        if p.name in {'credential.enc','credential.removed'}:
            raise ValueError('Private credential file selected for distribution')
        if not (p.suffix.lower() in {'.ini','.json','.yaml','.yml','.env'} or p.name.startswith('.env')):continue
        text=p.read_text(encoding='utf-8-sig')
        def walk(obj):
            if isinstance(obj,dict):
                for key,value in obj.items():
                    if key.lower() in SECRET_KEYS and value not in ('',None):raise ValueError('Nonempty credential in distribution configuration')
                    walk(value)
            elif isinstance(obj,list):
                for item in obj:walk(item)
        if p.suffix.lower()=='.json':
            try:walk(json.loads(text))
            except json.JSONDecodeError:raise ValueError('Invalid JSON selected for distribution') from None
        for line in text.splitlines():
            if line.lstrip().startswith(('#',';')):continue
            m=re.match(r'''\s*(?:export\s+)?["']?([A-Za-z_][A-Za-z0-9_]*)["']?\s*[:=]\s*(.*?)\s*[,]?$''',line)
            if m and m[1].lower() in SECRET_KEYS:
                value=m[2].split(' #',1)[0].split(' ;',1)[0].strip().strip('"\'')
                if value and value!='null':raise ValueError('Nonempty credential in distribution configuration')
