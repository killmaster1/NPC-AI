# Ferramentas históricas

`download_voice.py`, `download_class_voices.py` e `prepare_class_manifests.py` pertencem ao Piper antigo. Os manifestos `voice-faber.json`/`class-voices.json` não acompanham a distribuição atual. Não são etapas suportadas do build Kokoro/ElevenLabs; não os execute para instalar esta versão. Não foram apagados para preservar o histórico. A ferramenta suportada de runtime Kokoro é `build_tts.sh`; o modelo brasileiro fixado é documentado em `tts/dependencies.json`.

A preparação Java `build_keyboard.sh` contém downloads históricos ainda sem uma allowlist de hashes de fonte independente (B16). Não foi executada nem foram baixadas ferramentas nesta correção. Os jars existentes permitem testes JVM locais; isso não autentica sua procedência. Antes de regenerar DEX para distribuição, obtenha/verifique metadados de checksums confiáveis com autorização e acrescente manifesto verificável. Não inventar um hash a partir do próprio download.
