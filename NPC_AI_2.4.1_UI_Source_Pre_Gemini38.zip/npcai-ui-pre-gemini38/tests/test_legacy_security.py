import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
import server
class LegacySecurity(unittest.TestCase):
 def test_paid_requires_token(self):
  for mode in ['gemini','openai']:
   with self.assertRaises(ValueError):server.Server(('127.0.0.1',0),server.Service(server.Config(mode=mode),generator=lambda *a:'Fala'))
 def test_admission_limits(self):
  s=server.Service(server.Config(requests_per_minute=1),generator=lambda *a:'Fala')
  s.chat(('n','c'),'Oi',{})
  with self.assertRaises(server.Busy):s.chat(('n','c'),'Outra pergunta',{})
 def test_paid_with_token(self):
  s=server.Server(('127.0.0.1',0),server.Service(server.Config(mode='gemini',token='FICTITIOUS_TOKEN_1234'),generator=lambda *a:'Oi'))
  s.server_close()
 def test_paid_http_missing_wrong_correct_and_limit(self):
  import threading,json
  from http.client import HTTPConnection
  token='FICTITIOUS_TOKEN_1234';service=server.Service(server.Config(mode='gemini',token=token,requests_per_minute=1),generator=lambda *a:'Resposta mock do teste')
  http=server.Server(('127.0.0.1',0),service);worker=threading.Thread(target=http.serve_forever,kwargs={'poll_interval':.01});worker.start()
  try:
   def call(auth):
    connection=HTTPConnection('127.0.0.1',http.server_port,timeout=2);body=json.dumps({'npc_id':'n','message':'Oi'})
    connection.request('POST','/chat',body,{'Content-Type':'application/json','Authorization':auth});reply=connection.getresponse();status=reply.status;reply.read();connection.close();return status
   self.assertEqual(call(''),401);self.assertEqual(call('Bearer wrong'),401);self.assertEqual(call('Bearer '+token),200);self.assertEqual(call('Bearer '+token),429)
  finally:http.shutdown();http.server_close();worker.join(2)
