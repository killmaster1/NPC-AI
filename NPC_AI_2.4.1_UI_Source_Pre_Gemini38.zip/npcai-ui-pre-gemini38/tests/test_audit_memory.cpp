#include "intelligence_runtime.h"
#include <filesystem>
#include <fstream>
#include <future>
#include <iostream>
#include <cerrno>
#include <unistd.h>
using namespace npcai;namespace fs=std::filesystem;
#define CHECK(x) do{if(!(x))throw std::runtime_error(#x);}while(0)
static int writeError=0,writeCalls=0;
extern "C" ssize_t __real_write(int,const void*,size_t);
extern "C" ssize_t __wrap_write(int fd,const void* p,size_t n){if(writeError){if(writeCalls++==0)return __real_write(fd,p,std::min<size_t>(n,8));errno=writeError;return -1;}return __real_write(fd,p,n);}
static fs::path File(const fs::path& root){return root/("memory-"+IntegrityHash("profile")+".json");}
int main(){auto root=fs::temp_directory_path()/("npcai-audit-memory-"+SessionId());fs::create_directories(root);
 for(bool corrupt:{false,true})for(auto stage:{"write","file_synced","primary_publish","directory_sync"}){
  auto dir=root/(std::string(corrupt?"corrupt-":"valid-")+stage);NpcMemoryManager m(dir.string());CHECK(m.Load("profile"));CHECK(m.Note("n","primeira"));CHECK(m.Save());m.Note("n","segunda");CHECK(m.Save());
  if(corrupt){std::ofstream out(File(dir));out<<"broken";CHECK(out.good());}
  NpcMemoryManager recovered(dir.string());CHECK(recovered.Load("profile"));recovered.Note("n","nova");recovered.SetIoHook([&](auto s){return s!=stage;});CHECK(!recovered.Save());CHECK(recovered.Dirty());NpcMemoryManager next(dir.string());CHECK(next.Load("profile"));CHECK(!next.Notes({"n",false},false).empty());
 }
 for(auto stage:{"backup_write","backup_publish"}){auto dir=root/stage;NpcMemoryManager m(dir.string());m.Load("profile");m.Note("n","primeira");CHECK(m.Save());m.Note("n","segunda");m.SetIoHook([&](auto s){return s!=stage;});CHECK(!m.Save());NpcMemoryManager n(dir.string());CHECK(n.Load("profile") && n.Notes({"n",false},false).size()==1);}
 for(int error:{EIO,ENOSPC}){auto dir=root/std::to_string(error);NpcMemoryManager m(dir.string());m.Load("profile");m.Note("n","primeira");CHECK(m.Save());m.Note("n","segunda");writeError=error;writeCalls=0;bool ok=m.Save();writeError=0;CHECK(!ok && writeCalls>=2);NpcMemoryManager n(dir.string());CHECK(n.Load("profile") && n.Notes({"n",false},false).size()==1);}
 {auto dir=root/"snapshot";NpcMemoryManager m(dir.string());m.Load("profile");m.Note("n","primeira");auto snapshot=m;auto rev=m.Revision();m.Note("n","concorrente");CHECK(snapshot.Save());m.Acknowledge(snapshot,rev);CHECK(m.Dirty() && m.Notes({"n",false},false).size()==2);CHECK(m.Save());}
 {auto dir=root/"bad";fs::create_directories(dir);std::ofstream(File(dir))<<"bad";std::ofstream(File(dir).string()+".bak")<<"bad";NpcMemoryManager m(dir.string());CHECK(!m.Load("profile"));}
 {auto dir=root/"backup-only";NpcMemoryManager m(dir.string(),16384);m.Load("profile");m.Note("n","primeira");CHECK(m.Save());fs::rename(File(dir),File(dir).string()+".bak");CHECK(m.Load("profile"));m.Note("n","segunda");CHECK(m.Save());CHECK(fs::exists(File(dir).string()+".bak"));}
 // Deterministic storage barrier: live-state readers and decision admission must progress.
 std::promise<void> writing,release;auto gate=release.get_future().share();std::atomic_bool armed{false},once{false};
 Settings s;s.memoryProfile="manual";s.worldPerception=false;
 IntelligenceRuntime runtime(s,(root/"runtime").string(),{}, {},[&](const std::string& stage){if(stage=="write" && armed && !once.exchange(true)){writing.set_value();gate.wait();}return true;});
 Request r;r.npcId="n";r.conversationId="c";r.requestId="r";Decision d;d.dialogue="Fala natural.";runtime.Accepted(r,d);
 for(int i=0;i<1000 && runtime.DebugMemory()["npcs"].empty();++i){std::this_thread::sleep_for(std::chrono::milliseconds(2));}
 CHECK(!runtime.DebugMemory()["npcs"].empty());armed=true;runtime.Flush();CHECK(writing.get_future().wait_for(std::chrono::seconds(3))==std::future_status::ready);
 auto reader=std::async(std::launch::async,[&]{return runtime.DebugMemory();});bool free=reader.wait_for(std::chrono::milliseconds(200))==std::future_status::ready;
 // Admission is bounded and reports saturation, rather than dropping silently.
 bool full=false;for(int i=0;i<33;++i){try{r.requestId=std::to_string(i);runtime.Accepted(r,d);}catch(...){full=true;}}
 release.set_value();reader.wait();CHECK(free && full);runtime.Shutdown();
 {
  std::promise<void> entered2,release2;auto gate2=release2.get_future().share();std::atomic_bool armed2{false},once2{false};Settings settings;settings.worldPerception=false;
  IntelligenceRuntime ordered(settings,(root/"ordered").string(),{}, {},[&](const std::string& stage){if(stage=="write" && armed2 && !once2.exchange(true)){entered2.set_value();gate2.wait();}return true;});
  Request first;first.npcId="first";first.conversationId="c";first.requestId="first-r";ordered.Accepted(first,d);
  for(int i=0;i<1000 && ordered.DebugMemory()["npcs"].empty();++i){std::this_thread::sleep_for(std::chrono::milliseconds(2));}
  armed2=true;ordered.Flush();CHECK(entered2.get_future().wait_for(std::chrono::seconds(3))==std::future_status::ready);
  ordered.Slot(1,true);Request second=first;second.npcId="second";second.requestId="second-r";ordered.Accepted(second,d);
  Request canceled=first;canceled.npcId="canceled";auto token=std::make_shared<std::atomic_bool>(true);canceled.acceptanceCancelled=token;ordered.Accepted(canceled,d);
  ordered.Slot(2,true);Request third=first;third.npcId="third";third.requestId="third-r";ordered.Accepted(third,d);ordered.Slot(1,false);release2.set_value();
  Request check=first;check.npcId="validation";check.requestId="validation-r";std::atomic_bool neverCancel{false};CHECK(ordered.Chat(check,neverCancel).ok);
  for(int i=0;i<2000 && ordered.DebugMemory()["profile"]!="slot-1";++i){std::this_thread::sleep_for(std::chrono::milliseconds(2));}
  auto restored=ordered.DebugMemory();CHECK(restored["profile"]=="slot-1" && restored["npcs"].contains("second") && !restored["npcs"].contains("third") && !restored["npcs"].contains("canceled"));ordered.Shutdown();
 }
 fs::remove_all(root);std::cout<<"Audit memory: backup recovery, partial EIO/ENOSPC, publication faults, revision, bounded queue and slow storage passed\n";
}
