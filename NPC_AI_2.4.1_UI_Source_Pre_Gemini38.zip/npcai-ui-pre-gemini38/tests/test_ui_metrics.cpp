#include "ui.h"
#include "game_bridge.h"
#include "native_keyboard.h"
#include "../native/backend_control.h"
#include <mod/thirdparty/imgui/imgui.h>
#include <mod/thirdparty/imgui/imgui_internal.h>
#include <chrono>
#include <iostream>
#include <optional>

namespace {bool opened=true;}
namespace npcai::NativeKeyboard {
bool Show(const std::string&,const std::string&){return false;}bool Take(std::string&){return false;}
void Invalidate(){}bool Active(){return false;}void Heartbeat(){}
}
namespace npcai::GameBridge {
const char* Status(){return "NPC disponível";}bool Bubble(float&,float&,float,float){return false;}
void Open(bool value){opened=value;}void Sent(){opened=false;}bool IsOpen(){return opened;}void Switch(){}
}
void NpcImGuiCaptureAll(bool){}

int main(){
    ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize={1280,720};io.DeltaTime=1.f/60;
    unsigned char* pixels;int w,h;io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);
    npcai::Chat chat([](const npcai::Request&,const std::atomic_bool&){return npcai::Result{true,"Resposta"};});
    npcai::Target target{"metrics","Pedestre",257,2,{}};chat.Select(target);
    for(int i=0;i<24;++i)chat.LocalReply(target,"Uma fala curta usada apenas para medir o custo de desenho do histórico.");
    NpcUi::Init(chat);
    using Clock=std::chrono::steady_clock;long long elapsed=0;int vertices=0,commands=0,windows=0;float area=0;
    for(int frame=0;frame<330;++frame){
        const auto begin=Clock::now();ImGui::NewFrame();NpcUi::Draw();ImGui::Render();
        if(frame>=30)elapsed+=std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-begin).count();
    }
    auto* data=ImGui::GetDrawData();vertices=data?data->TotalVtxCount:0;commands=data?data->CmdListsCount:0;
    for(const auto* window:ImGui::GetCurrentContext()->Windows)if(window->Active && !(window->Flags&ImGuiWindowFlags_ChildWindow)){++windows;area+=window->Size.x*window->Size.y;}
    std::cout<<"ui_metric_ns_per_frame="<<elapsed/300<<" vertices="<<vertices<<" command_lists="<<commands<<" top_windows="<<windows<<" area="<<area<<"\n";
    NpcUi::Shutdown();chat.Shutdown();ImGui::DestroyContext();
}
