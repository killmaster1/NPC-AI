#include "intelligence_runtime.h"
#include "npc_action_controller.h"
#include "tts.h"
#include "visibility_budget.h"
#include "thread_ownership.h"
#include <future>
#include <iostream>
#include <numeric>
using namespace npcai;
#define CHECK(x) do{if(!(x))throw std::runtime_error(#x);}while(0)
static std::string Provider(const std::string& text){JsonValue body={{"candidates",JsonValue::array({{{"content",{{"parts",JsonValue::array({{{"text",text}}})}}}}})}};return JsonValue{{"status",200},{"body",body.dump()}}.dump();}
struct Engine:ActionEngine{ActionContext c{true,true,false,false,true,"eligible",1,false};ActionContext Inspect(const Target&)override{return c;}bool Start(const Target&,Action,int)override{return true;}Effect Poll(const Target&,Action)override{return Effect::Applied;}void Stop(const Target&)override{}bool PrepareMoney(const Target&)override{return true;}int SpawnMoney(const Target&,int,int)override{return 1;}bool PickupAlive(int)override{return true;}void RemovePickup(int)override{}};
struct Audio:VoiceAudio{bool Open(int,float)override{return true;}int Write(const int16_t*,size_t n)override{return n;}int64_t Head()override{return 0;}void Close()override{}};
struct Catalog:VoiceBackend{std::promise<void> entered;bool Load(std::string&)override{return true;}bool Generate(const std::string&,float,const std::atomic_bool&,const std::function<bool(const float*,size_t,int)>&)override{return false;}void Cancel()override{}uint64_t ModelBytes()const override{return 0;}void ControlCancelable(const std::string&,const std::string&,const std::atomic_bool& cancelled)override{entered.set_value();while(!cancelled)std::this_thread::sleep_for(std::chrono::milliseconds(1));}};
int main(){
 WorldEvent explosion;explosion.kind=WorldKind::Explosion;explosion.intensity=.9;explosion.confidence=.9;
 WorldFrame frame;frame.at=1000;frame.minuteOfDay=14*60;frame.nativeEvents={explosion};WorldEventDetector detector;CHECK(detector.Update(frame).size()==1);frame.at+=500;for(int i=0;i<100;++i){WorldEntity e;e.id=std::to_string(i);frame.entities.push_back(e);}auto events=detector.Update(frame);CHECK(events.size()==64 && events[0].kind==WorldKind::Explosion);
 ExpectationManager expectations;ExpectationSpec night;night.requireVisible=true;CHECK(!expectations.Register("impossible",{night},1000,3,frame));night.requireVisible=false;night.minConfidence=.5;CHECK(expectations.Register("possible",{night},1000,3,frame));WorldEvent change;change.kind=WorldKind::Night;change.at=1500;change.id="night";change.confidence=.9;WorldObserverSample observer;auto perceived=NpcPerception::Assess(change,observer);CHECK(perceived && !perceived->event.visual && expectations.Observe(*perceived).size()==1);
 auto quota=VisibilityAllocation(4,12,0);CHECK(quota==std::vector<int>({3,3,3,3}));auto a=VisibilityAllocation(20,12,0),b=VisibilityAllocation(20,12,12);for(int i=0;i<20;++i)CHECK(a[i]+b[i]>0);CHECK(VisibilityAllocation(0,12,0).empty());std::set<size_t> seenObservers;for(size_t round=0;round<4;++round){auto schedule=ObserverSchedule(5,4,round,true);CHECK(schedule.size()==4 && schedule[0]==0);seenObservers.insert(schedule.begin(),schedule.end());}CHECK(seenObservers.size()==5);
 for(auto engine:{"kokoro","elevenlabs"})for(bool enabled:{false,true}){
  Settings s;s.memoryPersistent=false;s.geminiEnabled=true;s.elevenMax=25;s.elevenTarget=20;s.spontaneousBudgetHour=1;s.ttsEngine=engine;s.ttsEnabled=enabled;std::string prompt;
  IntelligenceRuntime runtime(s,"",[&](const std::string&,const std::string& body,int,const std::atomic_bool&){prompt=body;return Provider("Primeira frase. Segunda frase de ação e coração.");});Request r;r.npcId="n";r.conversationId="c";r.requestId="r";r.message="Oi";std::atomic_bool cancel{false};auto reply=runtime.Chat(r,cancel);CHECK(reply.ok && reply.text=="Primeira frase. Segunda frase de ação e coração.");CHECK((prompt.find("Teto 25")!=std::string::npos)==(enabled && std::string(engine)=="elevenlabs"));
  LocalReply opportunity;opportunity.serial=1;opportunity.aiOpportunity=true;s.spontaneousBudgetHour=1;int admitted=0;CHECK(!runtime.AdmitSpontaneous(opportunity,[]{return false;}));CHECK(runtime.AdmitSpontaneous(opportunity,[&]{++admitted;return true;}));CHECK(!runtime.AdmitSpontaneous(opportunity,[&]{++admitted;return true;}));CHECK(admitted==1);opportunity.serial=2;CHECK(!runtime.AdmitSpontaneous(opportunity,[]{return true;}));runtime.Boundary();opportunity.serial=2;CHECK(!runtime.AdmitSpontaneous(opportunity,[]{return true;}));runtime.Shutdown();
 }
 Engine e;Settings s;NpcActionController actions(e,s,[](auto&,bool,auto&,int){});Target target;target.id="n";auto caps=actions.Capabilities(target);CHECK(caps.captured && caps.moneyMax==200 && !caps.actions.empty());e.c.eligible=false;e.c.reason="mission_ped";caps=actions.Capabilities(target);CHECK(caps.actions.empty() && caps.refusal=="mission_ped");
 ThreadOwnership ownership;CHECK(ownership.Record(true));std::thread other([&]{CHECK(!ownership.Record(false));});other.join();
 auto catalog=std::make_unique<Catalog>();auto entered=catalog->entered.get_future();VoiceManager voice(Settings{},std::move(catalog),std::make_unique<Audio>());voice.Control("refresh_voices");CHECK(entered.wait_for(std::chrono::seconds(3))==std::future_status::ready);auto shutdown=std::async(std::launch::async,[&]{voice.Shutdown();});CHECK(shutdown.wait_for(std::chrono::seconds(2))==std::future_status::ready);
 std::cout<<"Audit behavior: native danger priority, visibility fairness, expectations, text isolation, capabilities, admission, thread audit and catalog cancellation passed\n";
}
