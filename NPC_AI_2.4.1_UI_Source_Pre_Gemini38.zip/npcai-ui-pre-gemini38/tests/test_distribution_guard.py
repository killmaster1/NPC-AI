import importlib.util,tempfile,unittest,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('guard',root/'tools/distribution_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
class DistributionGuard(unittest.TestCase):
 def test_nonempty_sentinels_rejected_unchanged(self):
  for name,body in [('private.ini','gemini_api_key=FICTIONAL_SENTINEL'),('eleven.ini','elevenlabs_api_key=FICTIONAL_SENTINEL'),('.env','NPC_AI_TOKEN=FICTIONAL_SENTINEL'),('config.json',json.dumps({'nested':{'api_key':'FICTIONAL_SENTINEL'}})),('config.yml','token: FICTIONAL_SENTINEL')]:
   with tempfile.TemporaryDirectory() as d:
    p=Path(d)/name;p.write_text(body)
    with self.assertRaises(ValueError) as error:guard.check_files([p])
    self.assertNotIn('FICTIONAL_SENTINEL',str(error.exception));self.assertEqual(p.read_text(),body)
 def test_public_configs(self):guard.check_files([root/'config/npcai.ini',root/'server/.env.example'])
 def test_real_packager_refuses_before_zip_and_keeps_sources(self):
  import shutil,subprocess,uuid
  with tempfile.TemporaryDirectory() as d:
   temp=Path(d);(temp/'tools').mkdir();(temp/'config').mkdir();(temp/'libs/arm64-v8a').mkdir(parents=True)
   for name in ['package.py','distribution_guard.py']:shutil.copy2(root/'tools'/name,temp/'tools'/name)
   (temp/'libs/arm64-v8a/libnpcai.so').write_bytes(b'TEST_ONLY_NOT_AN_ELF')
   for name in ['Android.mk','Application.mk','build.sh','Probe.mk','README.md','CHANGELOG.md','LICENSE','NOTICE','.gitignore']:(temp/name).write_text('fixture')
   sentinel='FICTITIOUS_'+uuid.uuid4().hex;ini=temp/'config/npcai.ini';ini.write_text('gemini_api_key='+sentinel)
   failed=subprocess.run([sys.executable,str(temp/'tools/package.py')],capture_output=True,text=True)
   self.assertNotEqual(failed.returncode,0);self.assertNotIn(sentinel,failed.stdout+failed.stderr);self.assertEqual(ini.read_text(),'gemini_api_key='+sentinel);self.assertFalse(any((temp/'dist').glob('*.zip')))
   ini.write_text('gemini_api_key=\nelevenlabs_api_key=\ntoken=\n')
   passed=subprocess.run([sys.executable,str(temp/'tools/package.py')],capture_output=True,text=True)
   self.assertEqual(passed.returncode,0,passed.stderr)
   import zipfile
   with zipfile.ZipFile(next((temp/'dist').glob('*.zip'))) as z:
    self.assertIn('npcai-android/LICENSE',z.namelist());self.assertIn('npcai-android/config/npcai.ini',z.namelist());self.assertFalse(any(sentinel.encode() in z.read(n) for n in z.namelist()))
