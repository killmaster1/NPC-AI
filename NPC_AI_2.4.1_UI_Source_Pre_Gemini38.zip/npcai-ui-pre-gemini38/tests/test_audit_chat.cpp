#include "chat.h"
#include <future>
#include <iostream>
#include <stdexcept>
using namespace npcai;
#define CHECK(x) do{if(!(x))throw std::runtime_error(#x);}while(0)
int main(){
 std::promise<void> entered,release;auto gate=release.get_future().share();
 Chat chat([](const Request&,const std::atomic_bool&){return Result{true,"Resposta natural."};});Target t;t.id="npc-a";chat.Select(t);
 chat.SetDecisionObserver([&](const Request&,const Decision&){entered.set_value();gate.wait();});
 CHECK(chat.Send("Oi"));CHECK(entered.get_future().wait_for(std::chrono::seconds(3))==std::future_status::ready);
 auto read=std::async(std::launch::async,[&]{return chat.Get();});bool free=read.wait_for(std::chrono::milliseconds(200))==std::future_status::ready;
 release.set_value();read.wait();chat.Shutdown();CHECK(free);
 Chat throwing([](const Request&,const std::atomic_bool&){return Result{true,"Tudo certo."};});throwing.Select(t);
 throwing.SetDecisionObserver([](const Request&,const Decision&){throw std::runtime_error("test observer");});CHECK(throwing.Send("Oi"));
 for(int i=0;i<1000 && throwing.Get().waiting;++i)std::this_thread::sleep_for(std::chrono::milliseconds(2));
 CHECK(!throwing.Get().waiting && !throwing.Get().error.empty());CHECK(throwing.Get().messages.size()==1);
 throwing.SetDecisionObserver({});CHECK(throwing.Send("Outra pergunta"));
 for(int i=0;i<1000 && throwing.Get().waiting;++i)std::this_thread::sleep_for(std::chrono::milliseconds(2));
 CHECK(throwing.Get().messages.size()==3);throwing.Shutdown();
 Chat limited([](const Request&,const std::atomic_bool&){return Result{true,"Primeira frase. Segunda frase completa."};},2);limited.Select(t);Settings config;config.ttsEngine="elevenlabs";config.elevenMax=10;limited.ConfigureDialogue(config);uint64_t previous=0;
 for(int i=0;i<3;++i){CHECK(limited.Send("Oi"));for(int j=0;j<1000 && limited.Get().waiting;++j)std::this_thread::sleep_for(std::chrono::milliseconds(2));auto snap=limited.Get();CHECK(snap.messages.size()==2 && snap.revision>previous && snap.messages.back().text=="Primeira frase. Segunda frase completa.");previous=snap.revision;}
 limited.Clear();CHECK(limited.Get().messages.empty() && limited.Get().revision>previous);limited.Shutdown();
 std::cout<<"Audit chat: blocked/throwing observers do not retain UI mutex or poison next request\n";
}
