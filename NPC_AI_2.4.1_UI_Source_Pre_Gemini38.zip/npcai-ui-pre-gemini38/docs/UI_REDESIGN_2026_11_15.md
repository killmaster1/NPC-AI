# Redesign da interface de gameplay — revisão local

Esta alteração mantém a base 2.4.1 e redesenha somente a camada de interação. Não muda o contrato da IA, seleção de NPCs, ações, voz, memória ou percepção. Ela foi compilada e testada em host, mas ainda não foi validada em um GTA SA Android real.

## Solução implementada

- O chat deixou de ser uma janela de 96% da tela. Agora é um painel sem título, ancorado na parte inferior, com largura limitada e fundo escuro semitransparente.
- A fala atual permanece visível no modo recolhido. O histórico completo é aberto somente ao tocar em **Histórico**.
- O teclado PT-BR interno é o padrão. Ele tem letras, maiúsculas, números, pontuação, acentos, espaço e remoção UTF-8; pode ser recolhido sem fechar a conversa.
- O IME Android continua disponível pelo botão **Android**. No modo `native`, tocar no compositor abre diretamente o IME.
- Tocar em **Conversar** não abre mais o IME automaticamente. Isso evita que o teclado cubra a fala antes de o jogador decidir escrever.
- O balão foi reduzido a 160 bytes visuais, limitado em altura e continua clicável. Só um NPC selecionado gera balão.
- O diagnóstico continua disponível em um lançador separado e não é misturado ao histórico da conversa.
- No modo compacto, o backend captura somente os retângulos reais do ImGui. O jogo continua visível e toques fora da UI não são engolidos pelo overlay; enquanto a conversa está em edição, o bloqueio já existente do `CPad` continua evitando ações acidentais.

## Entrada de texto: decisão técnica

| Alternativa | Desempenho | Compatibilidade | UX/manutenção | Decisão |
|---|---:|---:|---|---|
| Teclado compacto ImGui | baixo custo; sem JNI durante a digitação | controlado pelo mod | previsível, recolhível e sempre mantém a fala visível | padrão |
| IME Android adaptativo | custo do sistema | varia conforme teclado/Android | melhor autocorreção; a altura do teclado não pode ser imposta pelo mod | opção preservada |
| Reconhecimento de fala | exigiria STT, permissão de microfone e ciclo de vida adicional | não existe na infraestrutura atual | TTS não reconhece a voz do jogador; reconhecimento contínuo seria inadequado | não implementado |

O editor Android existente já usa a Activity atual, `ADJUST_RESIZE`, área visível, ação IME Enviar e cancelamento com Voltar. Ele foi preservado. Não foi criado Dialog nem outra Activity. A opção compacta reduz a necessidade de abrir esse overlay, mas não tenta controlar a altura de teclados de terceiros.

## Configuração

```ini
npc_ui_input_mode=compact
npc_ui_history_expanded=0
npc_ui_diagnostic_button=1
npc_ui_scale=1.0
```

- `npc_ui_input_mode`: `compact` ou `native`.
- `npc_ui_history_expanded`: abre o histórico por padrão quando vale `1`.
- `npc_ui_diagnostic_button`: permite ocultar o lançador técnico durante a gameplay.
- `npc_ui_scale`: ajuste adicional entre `0.75` e `1.5`; a adaptação à resolução continua automática.

Valores inválidos são rejeitados individualmente pelo parser e os padrões seguros são mantidos.

## Desempenho observado no host

O harness `tests/test_ui_metrics.cpp` executou 300 quadros medidos em 1280×720, com 24 falas armazenadas. Ele mede somente construção de layout/draw data do ImGui em Linux; não mede FPS, GPU RenderWare ou custo no aparelho.

| Interface | ns/quadro no harness | vértices | listas de comandos | área das janelas superiores |
|---|---:|---:|---:|---:|
| anterior | 44.131 | 4.444 | 2 | 848.548 px² |
| compacta final | 7.942 | 736 | 2 | 164.000 px² |

O resultado reduz trabalho estrutural no cenário recolhido, mas não autoriza afirmar ganho de FPS no GTA. A fala atual e o histórico são armazenados em cache por `revision`; o transcript do editor Android só é construído quando o usuário solicita o IME. Não há blur, WebView, pós-processamento ou animação cara.

## Arquivos da alteração

- `native/src/npcai/ui.cpp`, `ui.h`: HUD compacto, teclado híbrido, histórico, balão e separação do diagnóstico.
- `native/src/npcai/ui_layout.h`: cálculo puro, responsivo e sem alocações.
- `native/src/npcai/settings.cpp`, `settings.h`, `config/npcai.ini`: opções persistentes.
- `native/main.cpp`: entrega das opções carregadas para a UI.
- `tests/test_ui.cpp`, `tests/test_ui_metrics.cpp`, `tests/test_native.cpp`, `tools/test.sh`: regressão e métricas.

## Validação pendente no aparelho

1. Conferir sobreposição com radar, vida/dinheiro e botões touch em diferentes layouts de HUD.
2. Confirmar que arrastar fora do painel não provoca ação indesejada enquanto `CPad` está suprimido.
3. Testar Gboard, SwiftKey e teclado OEM em Android 8+ nos modos retrato/paisagem.
4. Testar toque prolongado, múltiplos dedos, Voltar e troca/desaparecimento do NPC durante a edição.
5. Medir CPU/GPU/FPS e legibilidade em aparelhos modestos; nenhum ganho de FPS foi alegado pelos testes de host.

## Correção de toque após o primeiro teste real

O primeiro build renderizava as janelas novas, mas seus botões não recebiam toque. A causa era o filtro do backend: ele fazia um teste bit a bit contra `ImGuiWindowFlags_NoInputs`, que é uma combinação de `NoMouseInputs`, `NoNavInputs` e `NoNavFocus`. Como as janelas mobile usam `NoNav`, elas eram removidas da lista de retângulos clicáveis mesmo permitindo mouse/toque.

O filtro agora rejeita somente `NoMouseInputs` e janelas filhas. Um teste de regressão confirma que `NoNav` continua clicável e que janelas realmente marcadas como `NoMouseInputs` continuam excluídas.
