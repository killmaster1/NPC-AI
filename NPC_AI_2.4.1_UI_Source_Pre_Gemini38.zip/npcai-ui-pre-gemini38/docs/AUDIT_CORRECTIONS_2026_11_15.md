# Correções locais da auditoria — 15/11/2026

Base: NPC AI 2.4.1, GTA SA Android 2.10 ARM64/API26, AML >=1.4, C++17. Este é um conjunto **não publicado** de alterações sobre essa base; a versão exibida permanece 2.4.1. Sem commit, push ou release. Sem instalar dependências, baixar toolchains/modelos, usar credenciais reais ou chamar APIs pagas.

A pasta `/workspace/npcai-android-starter` não tem Git. Antes de editar, foram copiados 118 arquivos de código/ferramentas e seus hashes para `/workspace/npcai-audit-fixes-baseline`, fora das fontes. Não há AGENTS.md encontrado nesta árvore. O relatório foi lido do anexo fornecido; ele não estava na raiz do checkout. A árvore Git de distribuição permaneceu sem alterações.

## Resultado por achado

| ID | Resultado nesta entrega | Implementação / evidência |
|---|---|---|
| B01 | Corrigido nos caminhos exercitados | `memory_store.*`: temporário fsync, backup derivado somente de dados validados, principal nunca removido antes do rename atômico, fsync de diretório verificado, revisão e proteção das gerações ativas na retenção. Escrita parcial EIO/ENOSPC e falhas de publicação testadas. |
| B02 | Corrigido nos caminhos exercitados | `chat.cpp`, `intelligence_runtime.*`: callback fora do mutex do Chat, fila tipada FIFO para decisões/recibos/troca de perfil/limpeza, cópia persistível fora do lock vivo. Barreiras de armazenamento, saturação, cancelamento e múltiplos saves testados. |
| B03 | **Pendente** | Não há executável autenticado/build-id auditado ou hashes independentes das regiões. Versão textual e guardas anteriores permanecem; não certificam layouts. Nenhuma allowlist foi inventada. |
| B04 | **Pendente** | Fonte local do AML documenta OnModUnload como não garantido e contém callbacks e caminhos de dlclose; não há desmontagem comprovada de todos os hooks/serviços. Stop não é hot-unload seguro. Não foi acrescentado booleano ou callback vazio para alegar residência. |
| B05 | Corrigido para os formatos/chaves verificados | `distribution_guard.py`, ambos empacotadores: recusa configs selecionadas com segredos preenchidos; não altera arquivo privado. INI/env/JSON/YAML e o empacotador real foram testados em árvore isolada. |
| B06 | Corrigido no legado | HTTP pago exige token de pelo menos 16 caracteres; comparação constante; bind loopback preservado. Admissão tem teto temporal independente de concorrência. Testes HTTP locais com gerador falso, sem chave real. |
| B07 | Corrigido | `world_core.cpp`: baseline não elimina eventos nativos, prioridade de perigo antes de presenças, teto total continua 64. Primeiro snapshot e cem presenças com explosão testados. |
| B08 | Corrigido no escalonamento host | `visibility_budget.h`, `world_bridge.cpp`: cotas de consultas, uma amostra do jogador antes das entidades de cada observador, rotação dos observadores de interesse e das entidades. Até quatro observadores/12 consultas; sem reaproveitar visão antiga como verificada. LOS real exige aparelho. |
| B09 | Corrigido para os tipos atuais | Expectativas ambientais e perda de contato não aceitam require_visible; entidade e ambiente continuam distintos. Noite verificável, combinação impossível e evidência não visual testadas. |
| B10 | Corrigido | Limites ElevenLabs somente no prompt aplicável e no backend de voz; não truncam histórico/balões/Kokoro/texto sem voz. Dois enunciados e UTF-8 com limite de voz baixo testados. |
| B11 | Corrigido no caminho compartilhado | `NpcUi::SubmitMessage` usado por touch/IME; chama Sent somente depois de admissão. Testes UI verificam envio aceito e rejeitado. IME/touch reais pendentes. |
| B12 | Implementado; Android pendente | `NativeKeyboard::Version` usa PackageManager da plataforma antes de DEX/editor. Editor pode falhar sem apagar versão já comprovada. Versão desconhecida continua impedindo integração. Compilado com NDK; lifecycle/JNI real não testado. |
| B13 | Corrigido no agendamento host | Comandos de catálogo usam token/deadline do VoiceManager; cancelamento, troca de motor e shutdown compartilham o caminho. Catálogo bloqueado com backend falso testado. |
| B14 | Corrigido | Oportunidade não consome orçamento. Reserva na admissão, confirma se Enqueue aceita, libera se rejeita; deduplicação por serial/epoch e prazo por hora. Testes de descarte, fila recusada, duplicação e limite. |
| B15 | Pré-checagem implementada; engine pendente | Capabilities capturadas na atualização do jogo: estados nomeados, símbolos disponíveis, whitelist, motivo tipado e limites monetários restantes. Contexto compacto e schema monetário recebem os dados. Não garante task/slot/modelo carregado: execução sempre revalida. Nenhuma leitura de CPed na worker. |
| B16 | **Pendente** | Jars disponíveis permitiram testes JVM; isso não autentica procedência. Não havia manifesto confiável de hashes independentes. Sem autorização de download, não buscamos nem inventamos checksums. `build_keyboard.sh` não foi executado. |
| B17 | Classificado e bloqueado | Ferramentas Piper com manifestos ausentes encerram com instrução explícita, antes de rede; ver `tools/HISTORICAL_TOOLS.md`. Mantidas para histórico. |
| B18 | Corrigido | Revisão de conversa cresce nos envios/publicações/limpeza; autoscroll usa revisão e respeita usuário lendo mensagens antigas. Teste com histórico cheio e mesmo número de mensagens. |
| B19 | Corrigido nos caminhos exercitados | Exceção do observador vira diagnóstico, não publica proposta e libera busy; próxima requisição funciona. Worker de inteligência contém falha e interrompe gravações/admissões se perder consistência de controle. Não promete recuperação universal de OOM. |
| B20 | Instrumentação; **race real pendente** | `thread_ownership.h` registra IDs game/render e loga a primeira divergência/mudança. Não prova que callbacks Android compartilhem thread nem corrige uma race ainda não observada; não foram colocados locks cegos em chamadas da engine. |

## Persistência, locks e limites

`NpcMemoryManager` continua exigindo proprietário/lock externo. O worker faz cópia com revisão, grava fora de stateMutex e reconhece sucesso somente para o mesmo perfil/revisão. Uma alteração posterior continua dirty. Save/load/clear são serializados pelo mesmo worker; não há uma thread por NPC ou gravações paralelas do mesmo perfil.

O protocolo escreve e sincroniza o novo temporário, publica/sincroniza backup somente a partir do principal validado, publica o principal com rename e sincroniza seu diretório. Se o principal estava corrompido, o .bak recuperado fica intocado. Erros de write/close/fsync/rename são falhas, mesmo se o novo arquivo já estiver visível. Permissões: diretório 0700 e arquivos 0600. O formato schema 1/2 continua legível; futuros schemas mantêm a proteção existente.

A garantia depende do filesystem, do dispositivo honrar fsync/rename e de não haver outro escritor manipulando os mesmos arquivos. Não é proteção contra corrupção arbitrária, falha total do armazenamento ou mod malicioso no mesmo UID. O orçamento de retenção é flexível para preservar a geração ativa e seu backup; perfis antigos continuam sujeitos à política de retenção existente. Falhas podem deixar temporários ignorados na recuperação, sobrescritos na tentativa seguinte.

Fila de controle: até 128 eventos, no máximo 32 decisões pendentes (espaço reservado aos controles/recibos). Saturação de decisões recusa a resposta antes da publicação e mostra erro. Se saturar o limite absoluto de controles, gravações e novas admissões de IA são interrompidas para não associar memória ao save errado; há métrica/log e é necessário reiniciar. A UI e as operações de diagnóstico não dependem desse sucesso. Callbacks externos não executam sob o mutex do Chat; logging do worker ocorre fora do lock vivo. Oportunidades espontâneas usam reserva/confirmacão/liberação sem executar Enqueue sob o lock da fila.

## Configuração e migração

- Native Gemini/Mock/Kokoro/ElevenLabs e seus parâmetros permanecem. Não houve atualização de dependências, modelo, offsets, IDs de animação ou stack.
- No **servidor legado pago**, preencha `NPC_AI_TOKEN` privado com ao menos 16 caracteres e o mesmo `token=` no INI privado do cliente. Não copie essa senha para exemplos distribuídos. Mock sem token é somente desenvolvimento local e não permite mudar o modo pelo HTTP.
- `NPC_AI_REQUESTS_PER_MINUTE=30` e `NPC_AI_CHARACTERS_PER_HOUR=30000`: valores padrão de admissão do legado. Contam pedidos e caracteres de entrada, não tokens/saída/faturamento; ficam em RAM e reiniciam com o servidor. Retry do provedor e cobrança real continuam independentes. Cache idempotente não é cobrado novamente na admissão.
- Configuração pública deve ter token e chaves vazios. Os empacotadores recusam configurações preenchidas; não apagam nem sanitizam silenciosamente o arquivo privado. `NPC_AI_DIST_DIR` permite gerar para uma pasta de build sem sobrescrever pacotes anteriores.
- O texto autorizado permanece no histórico (limites gerais existentes de validação/UTF-8/quantidade); só a síntese ElevenLabs pode escolher uma frase completa dentro do orçamento. Uma voz limitada não reduz a fala textual do NPC.
- O caminho oficial de regeneração DEX continua dependente da validação externa B16. Java não mudou nesta entrega; o DEX existente não foi editado/regenerado manualmente. O build nativo reutiliza esse mesmo DEX incorporado.

## Verificações executadas

Comandos e logs atuais acompanham `docs/validation/audit-2026-11-15/`:

```bash
NPC_AI_JAVA_TOOLS=/workspace/npcai-java-tools ./tools/test.sh
ANDROID_NDK_HOME=/workspace/toolchains/android-ndk-r27d ./build.sh
python3 tools/verify_tts_elf.py runtime/arm64-v8a/*.so
```

- Suíte: **97 testes Python/JVM aprovados**, regressões C++ existentes (incluindo 176 cenários dos grupos anteriores), UI e três executáveis novos de auditoria.
- `test_audit_chat`: observador bloqueado não segura Get; observador que lança não prende busy nem impede próxima pergunta; histórico cheio cresce por revisão e preserva texto integral com teto de voz pequeno.
- `test_audit_memory`: principal/backup, escrita parcial EIO/ENOSPC via wrapper de write, estágios de publicação/sync, recuperação por nova instância, revisão concorrente, fila cheia, armazenamento retido por barreira, duas trocas de save em sequência e decisão cancelada.
- `test_audit_behavior`: eventos iniciais/saturados, quotas/rotação, expectativas possíveis, texto independente do motor, capacidades/missão, admissão espontânea e cancelamento de catálogo no shutdown.
- Testes novos Python: sentinelas fictícias em configurações, fonte privada inalterada, recusa antes de criar ZIP, fontes/licenças no pacote sanitizado; autenticação HTTP paga/token/429 e tetos locais.
- ASan/UBSan com leak detection no teste de persistência/runtime; TSan no teste de chat/observador. Não abrangem o SDK/engine/Java/ONNX inteiro.
- Compilação Android real com NDK r27d/API26 e verificação ELF AArch64/AML/LOAD 16 KiB. Runtimes Kokoro existentes também verificados, sem substituição de binários Linux por Android.
- Não houve APK/GTA executando, teste de aparelho, síntese neural nova, chamada real Gemini/ElevenLabs, medição de FPS/PSS/bateria ou download. Os resultados da auditoria anterior permanecem históricos; os 97 resultados acima são desta execução com jars já disponíveis.

## Invariantes e pendências

Registry, identidade geracional, whitelist, propriedade de tarefas/pickups, missão/combate/veículo, deduplicação e recibos reais continuam no controlador. Capacidades enviadas ao modelo não concedem permissão nem comprovam efeito. As regressões existentes exercitam cancelamento, reciclagem, respostas antigas, dinheiro duplicado, falhas de rede e rendição.

No aparelho: verificar IME/touch e controles, game/render IDs, build real e hooks, missões/combate, despawn/reciclagem, troca de saves/interiores, pause/resume, consulta de vozes cancelada, armazenamento lento/falho, mistura de mods e sessões prolongadas. B03/B04/B16/B20 permanecem explicitamente abertos. Não declarar todos os achados resolvidos nem certificar estabilidade no GTA pelos testes host.

As funcionalidades novas propostas estão em `AI_ROADMAP_PROPOSAL.md`; nenhuma foi implementada.
